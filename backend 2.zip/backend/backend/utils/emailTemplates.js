const STORE_NAME = "MobileShop";
const STORE_URL = process.env.FRONTEND_URL || "http://localhost:3000";
const STORE_EMAIL = process.env.EMAIL_USER || "support@mobileshop.com";

const emailWrapper = (content, title) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
</head>
<body style="margin:0;padding:0;background-color:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f5f5f5;padding:20px 0;">
    <tr>
      <td align="center">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="background-color:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.08);">
          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,#0f172a 0%,#16213e 100%);padding:30px 40px;text-align:center;">
              <h1 style="color:#ffffff;margin:0;font-size:28px;font-weight:bold;">${STORE_NAME}</h1>
              <p style="color:#cbd5e1;margin:5px 0 0 0;font-size:14px;">Premium Mobile Phones</p>
            </td>
          </tr>
          <!-- Content -->
          <tr>
            <td style="padding:40px;">
              ${content}
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="background-color:#f8fafc;padding:25px 40px;text-align:center;border-top:1px solid #e2e8f0;">
              <p style="color:#64748b;margin:0 0 10px 0;font-size:13px;">
                &copy; ${new Date().getFullYear()} ${STORE_NAME}. All rights reserved.
              </p>
              <p style="color:#94a3b8;margin:0;font-size:12px;">
                ${STORE_URL} | ${STORE_EMAIL}
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

const welcomeEmail = (userName, verifyLink) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">Welcome to ${STORE_NAME}, ${userName}! 🎉</h2>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 15px 0;">
    Thank you for joining ${STORE_NAME}! We're excited to help you find your perfect mobile phone.
  </p>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 25px 0;">
    Please verify your email address to activate your account:
  </p>
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:0 0 25px 0;">
    <tr>
      <td style="background-color:#e94560;border-radius:8px;">
        <a href="${verifyLink}" style="display:inline-block;padding:14px 32px;color:#ffffff;text-decoration:none;font-weight:bold;font-size:15px;">Verify Email Address</a>
      </td>
    </tr>
  </table>
  <p style="color:#64748b;font-size:13px;line-height:1.5;margin:0;">
    If the button doesn't work, copy and paste this link into your browser:<br>
    <a href="${verifyLink}" style="color:#e94560;word-break:break-all;">${verifyLink}</a>
  </p>
  <p style="color:#64748b;font-size:13px;line-height:1.5;margin:20px 0 0 0;">
    This link expires in 24 hours. If you didn't create an account, please ignore this email.
  </p>
`, "Welcome to MobileShop");

const loginAlertEmail = (userName, ip, device, time) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">New Login Detected 🔐</h2>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 20px 0;">
    Hi ${userName}, we detected a new login to your ${STORE_NAME} account.
  </p>
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f8fafc;border-radius:8px;padding:20px;margin:0 0 20px 0;">
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;"><strong>IP Address:</strong></td>
      <td style="padding:8px 0;color:#0f172a;font-size:14px;">${ip}</td>
    </tr>
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;"><strong>Device:</strong></td>
      <td style="padding:8px 0;color:#0f172a;font-size:14px;">${device}</td>
    </tr>
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;"><strong>Time:</strong></td>
      <td style="padding:8px 0;color:#0f172a;font-size:14px;">${time}</td>
    </tr>
  </table>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0;">
    If this was you, you can safely ignore this email. If you didn't log in, please change your password immediately and contact support.
  </p>
`, "New Login Alert");

const passwordResetEmail = (userName, resetLink) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">Reset Your Password 🔑</h2>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 25px 0;">
    Hi ${userName}, we received a request to reset your password. Click the button below to create a new one.
  </p>
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:0 0 25px 0;">
    <tr>
      <td style="background-color:#e94560;border-radius:8px;">
        <a href="${resetLink}" style="display:inline-block;padding:14px 32px;color:#ffffff;text-decoration:none;font-weight:bold;font-size:15px;">Reset Password</a>
      </td>
    </tr>
  </table>
  <p style="color:#64748b;font-size:13px;line-height:1.5;margin:0;">
    If the button doesn't work, copy and paste this link:<br>
    <a href="${resetLink}" style="color:#e94560;word-break:break-all;">${resetLink}</a>
  </p>
  <p style="color:#64748b;font-size:13px;line-height:1.5;margin:20px 0 0 0;">
    This link expires in 10 minutes. If you didn't request a password reset, please ignore this email — your password will remain unchanged.
  </p>
`, "Password Reset Request");

const passwordResetConfirmEmail = (userName) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">Password Changed Successfully ✅</h2>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 15px 0;">
    Hi ${userName}, your password has been changed successfully.
  </p>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0;">
    If you didn't make this change, please contact our support team immediately at ${STORE_EMAIL}.
  </p>
`, "Password Changed");

const orderConfirmationEmail = (order) => {
  const itemsHtml = order.items.map(item => `
    <tr>
      <td style="padding:12px;border-bottom:1px solid #e2e8f0;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0">
          <tr>
            <td style="padding-right:15px;">
              <img src="${item.image}" alt="${item.name}" width="60" height="60" style="border-radius:6px;object-fit:cover;">
            </td>
            <td>
              <p style="color:#0f172a;margin:0;font-size:14px;font-weight:bold;">${item.name}</p>
              <p style="color:#64748b;margin:3px 0 0 0;font-size:12px;">Qty: ${item.quantity}</p>
            </td>
          </tr>
        </table>
      </td>
      <td style="padding:12px;border-bottom:1px solid #e2e8f0;text-align:right;color:#0f172a;font-size:14px;font-weight:bold;">₦${item.price.toLocaleString()}</td>
    </tr>
  `).join("");

  return emailWrapper(`
    <h2 style="color:#0f172a;margin:0 0 10px 0;font-size:22px;">Order Confirmed! 🎉</h2>
    <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 25px 0;">
      Thank you for your order! Your order number is <strong style="color:#e94560;">${order.orderNumber}</strong>.
    </p>
    
    <h3 style="color:#0f172a;margin:0 0 15px 0;font-size:17px;">Order Items</h3>
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin:0 0 20px 0;">
      ${itemsHtml}
    </table>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f8fafc;border-radius:8px;padding:20px;margin:0 0 25px 0;">
      <tr>
        <td style="padding:8px 0;color:#64748b;font-size:14px;">Subtotal</td>
        <td style="padding:8px 0;text-align:right;color:#0f172a;font-size:14px;">₦${order.subtotal.toLocaleString()}</td>
      </tr>
      <tr>
        <td style="padding:8px 0;color:#64748b;font-size:14px;">Shipping</td>
        <td style="padding:8px 0;text-align:right;color:#0f172a;font-size:14px;">${order.shippingFee > 0 ? '₦' + order.shippingFee.toLocaleString() : 'FREE'}</td>
      </tr>
      ${order.tax > 0 ? `<tr><td style="padding:8px 0;color:#64748b;font-size:14px;">Tax</td><td style="padding:8px 0;text-align:right;color:#0f172a;font-size:14px;">₦${order.tax.toLocaleString()}</td></tr>` : ''}
      <tr>
        <td style="padding:12px 0;color:#0f172a;font-size:16px;font-weight:bold;border-top:2px solid #e2e8f0;">Total</td>
        <td style="padding:12px 0;text-align:right;color:#e94560;font-size:18px;font-weight:bold;border-top:2px solid #e2e8f0;">₦${order.total.toLocaleString()}</td>
      </tr>
    </table>
    
    <h3 style="color:#0f172a;margin:0 0 15px 0;font-size:17px;">Shipping Address</h3>
    <p style="color:#475569;font-size:14px;line-height:1.6;margin:0;">
      <strong>${order.shippingAddress.fullName}</strong><br>
      ${order.shippingAddress.street}<br>
      ${order.shippingAddress.city}, ${order.shippingAddress.state}<br>
      ${order.shippingAddress.country}<br>
      Phone: ${order.shippingAddress.phone}
    </p>
  `, "Order Confirmation");
};

const paymentReceiptEmail = (order) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 10px 0;font-size:22px;">Payment Received 💳</h2>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 25px 0;">
    Your payment of <strong style="color:#e94560;">₦${order.total.toLocaleString()}</strong> has been received successfully.
  </p>
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f8fafc;border-radius:8px;padding:20px;margin:0 0 25px 0;">
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;">Order Number</td>
      <td style="padding:8px 0;text-align:right;color:#0f172a;font-size:14px;font-weight:bold;">${order.orderNumber}</td>
    </tr>
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;">Payment Reference</td>
      <td style="padding:8px 0;text-align:right;color:#0f172a;font-size:14px;font-family:monospace;">${order.paymentReference || 'N/A'}</td>
    </tr>
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;">Payment Method</td>
      <td style="padding:8px 0;text-align:right;color:#0f172a;font-size:14px;">${order.paymentMethod}</td>
    </tr>
    <tr>
      <td style="padding:8px 0;color:#64748b;font-size:14px;">Amount Paid</td>
      <td style="padding:8px 0;text-align:right;color:#e94560;font-size:16px;font-weight:bold;">₦${order.total.toLocaleString()}</td>
    </tr>
  </table>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0;">
    We'll process your order and ship it as soon as possible. You'll receive another email when your order ships.
  </p>
`, "Payment Receipt");

const adminNotificationEmail = (subject, message) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">${subject}</h2>
  <div style="color:#475569;font-size:15px;line-height:1.6;">
    ${message}
  </div>
`, "Admin Notification");

const shippingUpdateEmail = (order, status) => {
  const statusMessages = {
    shipped: "Your order has been shipped! 🚚",
    delivered: "Your order has been delivered! 📦",
    cancelled: "Your order has been cancelled"
  };
  return emailWrapper(`
    <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">${statusMessages[status] || 'Order Status Updated'}</h2>
    <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 15px 0;">
      Order <strong>${order.orderNumber}</strong> status has been updated to:
    </p>
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:0 0 25px 0;">
      <tr>
        <td style="background-color:#e94560;color:#ffffff;padding:10px 24px;border-radius:8px;font-weight:bold;font-size:16px;text-transform:capitalize;">
          ${status}
        </td>
      </tr>
    </table>
    <p style="color:#475569;font-size:15px;line-height:1.6;margin:0;">
      You can track your order status in your account dashboard.
    </p>
  `, "Order Status Update");
};

const contactAutoReplyEmail = (userName) => emailWrapper(`
  <h2 style="color:#0f172a;margin:0 0 20px 0;font-size:22px;">Thanks for Contacting Us! ✉️</h2>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 15px 0;">
    Hi ${userName}, thank you for reaching out to ${STORE_NAME}.
  </p>
  <p style="color:#475569;font-size:15px;line-height:1.6;margin:0;">
    We've received your message and our support team will get back to you within 24-48 hours.
  </p>
`, "Contact Form Submission");

module.exports = {
  welcomeEmail,
  loginAlertEmail,
  passwordResetEmail,
  passwordResetConfirmEmail,
  orderConfirmationEmail,
  paymentReceiptEmail,
  adminNotificationEmail,
  shippingUpdateEmail,
  contactAutoReplyEmail
};
