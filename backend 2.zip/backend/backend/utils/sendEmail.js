const createTransporter = require("../config/mailer");
const EmailLog = require("../models/EmailLog");

const sendEmail = async ({ to, subject, html, type = "admin-notification", userId = null, orderId = null }) => {
  try {
    const transporter = createTransporter();
    
    const mailOptions = {
      from: `"MobileShop" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      html
    };

    await transporter.sendMail(mailOptions);

    // Log the email
    await EmailLog.create({
      to,
      subject,
      type,
      html,
      status: "sent",
      user: userId,
      order: orderId
    });

    return true;
  } catch (error) {
    console.error("Email send error:", error.message);
    
    // Log the failure
    try {
      await EmailLog.create({
        to,
        subject,
        type,
        html,
        status: "failed",
        error: error.message,
        user: userId,
        order: orderId
      });
    } catch (logError) {
      console.error("Failed to log email:", logError.message);
    }
    
    return false;
  }
};

const notifyAdmin = async (subject, message, type = "admin-notification") => {
  const templates = require("./emailTemplates");
  const html = templates.adminNotificationEmail(subject, message);
  
  return sendEmail({
    to: process.env.ADMIN_EMAIL,
    subject: `[Admin] ${subject}`,
    html,
    type
  });
};

module.exports = { sendEmail, notifyAdmin };
