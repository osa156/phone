const express = require("express");
const {
  initializePayment,
  verifyPayment,
  handleWebhook
} = require("../controllers/paymentController");

const router = express.Router();

// Webhook must use raw body - handled in server.js
router.post("/webhook", handleWebhook);
router.post("/initialize", initializePayment);
router.post("/verify", verifyPayment);

module.exports = router;
