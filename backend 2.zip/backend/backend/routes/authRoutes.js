const express = require("express");
const { body } = require("express-validator");
const {
  signup,
  login,
  logout,
  getMe,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
  verifyEmail
} = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");
const { authLimiter } = require("../middleware/rateLimiter");

const router = express.Router();

router.post("/signup", authLimiter, [
  body("fullName").notEmpty().withMessage("Full name is required"),
  body("email").isEmail().withMessage("Please provide a valid email"),
  body("password").isLength({ min: 8 }).withMessage("Password must be at least 8 characters"),
  body("phone").notEmpty().withMessage("Phone number is required")
], signup);

router.post("/login", authLimiter, [
  body("email").isEmail().withMessage("Please provide a valid email"),
  body("password").notEmpty().withMessage("Password is required")
], login);

router.post("/logout", logout);

router.get("/me", protect, getMe);

router.put("/profile", protect, updateProfile);

router.put("/password", protect, [
  body("currentPassword").notEmpty().withMessage("Current password is required"),
  body("newPassword").isLength({ min: 8 }).withMessage("New password must be at least 8 characters")
], changePassword);

router.post("/forgot-password", authLimiter, [
  body("email").isEmail().withMessage("Please provide a valid email")
], forgotPassword);

router.put("/reset-password/:token", authLimiter, [
  body("password").isLength({ min: 8 }).withMessage("Password must be at least 8 characters")
], resetPassword);

router.get("/verify-email/:token", verifyEmail);

module.exports = router;
