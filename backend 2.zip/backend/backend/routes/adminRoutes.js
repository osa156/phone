const express = require("express");
const { body } = require("express-validator");
const {
  getDashboardStats,
  getAllOrders,
  updateOrderStatus,
  createProduct,
  updateProduct,
  deleteProduct,
  getAllProductsAdmin,
  getEmailLogs,
  exportOrdersCSV
} = require("../controllers/adminController");

const router = express.Router();

// All admin routes are now PUBLIC (no authentication)
router.get("/stats", getDashboardStats);
router.get("/orders", getAllOrders);
router.put("/orders/:id/status", updateOrderStatus);

router.post("/products", [
  body("brand").isIn(["Infinix", "Apple", "Samsung"]).withMessage("Invalid brand"),
  body("model").notEmpty().withMessage("Model is required"),
  body("year").isInt({ min: 2022, max: 2026 }).withMessage("Year must be between 2022 and 2026"),
  body("price").isNumeric({ min: 0 }).withMessage("Valid price is required"),
  body("description").notEmpty().withMessage("Description is required")
], createProduct);

router.put("/products/:id", updateProduct);
router.delete("/products/:id", deleteProduct);
router.get("/products", getAllProductsAdmin);
router.get("/emails", getEmailLogs);
router.get("/export/orders", exportOrdersCSV);

module.exports = router;
