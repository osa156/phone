const express = require("express");
const { body } = require("express-validator");
const {
  createOrder,
  getOrdersByEmail,
  getOrderByLookup,
  getOrderById,
  cancelOrder
} = require("../controllers/orderController");

const router = express.Router();

// All order routes are now public
router.post("/", [
  body("items").isArray({ min: 1 }).withMessage("At least one item is required"),
  body("shippingAddress.fullName").notEmpty().withMessage("Full name is required"),
  body("shippingAddress.phone").notEmpty().withMessage("Phone is required"),
  body("shippingAddress.street").notEmpty().withMessage("Street address is required"),
  body("shippingAddress.city").notEmpty().withMessage("City is required"),
  body("shippingAddress.state").notEmpty().withMessage("State is required")
], createOrder);

router.get("/lookup", getOrdersByEmail);
router.get("/lookup-one", getOrderByLookup);
router.get("/:id", getOrderById);
router.put("/:id/cancel", cancelOrder);

module.exports = router;
