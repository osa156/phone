const express = require("express");
const { body } = require("express-validator");
const {
  getProducts,
  getFeaturedProducts,
  getNewArrivals,
  getProductBySlug,
  getRelatedProducts,
  addReview
} = require("../controllers/productController");

const router = express.Router();

// All product routes are public
router.get("/", getProducts);
router.get("/featured", getFeaturedProducts);
router.get("/new-arrivals", getNewArrivals);
router.get("/:slug", getProductBySlug);
router.get("/:id/related", getRelatedProducts);
router.post("/:id/reviews", [
  body("rating").isInt({ min: 1, max: 5 }).withMessage("Rating must be between 1 and 5"),
  body("comment").optional().isLength({ max: 500 }).withMessage("Comment must be less than 500 characters")
], addReview);

module.exports = router;
