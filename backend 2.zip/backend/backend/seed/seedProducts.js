require("dotenv").config({ path: "../.env" });
const mongoose = require("mongoose");
const Product = require("../models/Product");

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/mobile_shop")
  .then(() => console.log("MongoDB connected for seeding..."))
  .catch(err => {
    console.error("MongoDB connection error:", err.message);
    process.exit(1);
  });

// Helper: generate slug
const makeSlug = (brand, model, year) => 
  `${brand}-${model}-${year}`.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");

// Helper: random rating between 4.0 and 4.9
const randomRating = () => Math.round((4.0 + Math.random() * 0.9) * 10) / 10;
const randomReviews = () => Math.floor(Math.random() * 200) + 10;
const randomStock = () => Math.floor(Math.random() * 80) + 15;

// Image base URLs (using GSMArena CDN and official sources)
const img = (brand, model, n = 1) => {
  const safeModel = model.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
  const safeBrand = brand.toLowerCase();
  return `https://fdn2.gsmarena.com/vv/pics/${safeBrand}/${safeBrand}-${safeModel}-${n}.jpg`;
};

// All 75 products
const products = [
  // ==================== INFINIX 2022 ====================
  {
    brand: "Infinix", model: "Zero 5G", year: 2022,
    price: 280000, originalPrice: 320000,
    description: "The Infinix Zero 5G features a powerful Dimensity 900 processor, 120Hz display, and 5G connectivity for blazing-fast speeds.",
    specifications: {
      display: "6.78\" FHD+ IPS LCD, 120Hz, 500 nits",
      processor: "MediaTek Dimensity 900 5G (6nm)",
      ram: "8GB LPDDR5",
      storage: "128GB UFS 3.1",
      camera: "48MP Main + 13MP Ultrawide + 2MP Depth, 16MP Front",
      battery: "5000mAh, 33W Fast Charging",
      os: "Android 11, XOS 10",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.2, USB-C",
      weight: "199g",
      dimensions: "164.7 x 76.9 x 8.8 mm"
    },
    images: [img("infinix", "zero-5g", 1), img("infinix", "zero-5g", 2), img("infinix", "zero-5g", 3)],
    colors: [{ name: "Cosmic Black", hex: "#1a1a2e" }, { name: "Silver", hex: "#c0c0c0" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Note 12 Pro", year: 2022,
    price: 265000, originalPrice: 300000,
    description: "Infinix Note 12 Pro boasts a stunning AMOLED display, 108MP camera, and Helio G99 processor for exceptional performance.",
    specifications: {
      display: "6.7\" FHD+ AMOLED, 10-bit, 1000 nits peak",
      processor: "MediaTek Helio G99 (6nm)",
      ram: "8GB LPDDR4X",
      storage: "256GB UFS 2.2",
      camera: "108MP Main + 2MP Depth + 2MP Macro, 16MP Front",
      battery: "5000mAh, 33W Fast Charging",
      os: "Android 12, XOS 10.6",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C",
      weight: "188g",
      dimensions: "164.6 x 76.9 x 7.9 mm"
    },
    images: [img("infinix", "note-12-pro", 1), img("infinix", "note-12-pro", 2), img("infinix", "note-12-pro", 3)],
    colors: [{ name: "Force Black", hex: "#0f0f1a" }, { name: "Sunset Gold", hex: "#d4a574" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Hot 12", year: 2022,
    price: 125000, originalPrice: 145000,
    description: "The Infinix Hot 12 delivers great value with a 90Hz display, 50MP camera, and long-lasting battery.",
    specifications: {
      display: "6.6\" HD+ IPS LCD, 90Hz",
      processor: "MediaTek Helio G85 (12nm)",
      ram: "6GB LPDDR4X",
      storage: "128GB eMMC 5.1",
      camera: "50MP Main + 2MP Depth + AI Lens, 8MP Front",
      battery: "5000mAh, 18W Charging",
      os: "Android 11, XOS 10.6",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C",
      weight: "191g",
      dimensions: "163.5 x 75.5 x 8.7 mm"
    },
    images: [img("infinix", "hot-12", 1), img("infinix", "hot-12", 2), img("infinix", "hot-12", 3)],
    colors: [{ name: "Racing Black", hex: "#0a0a0a" }, { name: "Electric Blue", hex: "#1e90ff" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Smart 6", year: 2022,
    price: 95000, originalPrice: 110000,
    description: "The Infinix Smart 6 is an affordable entry-level smartphone with a large HD+ display and reliable performance.",
    specifications: {
      display: "6.6\" HD+ IPS LCD",
      processor: "Unisoc SC9863A (28nm)",
      ram: "2GB LPDDR3",
      storage: "32GB eMMC",
      camera: "8MP Main + 2MP Depth, 5MP Front",
      battery: "5000mAh, 10W Charging",
      os: "Android 11 (Go edition)",
      connectivity: "4G LTE, Wi-Fi, Bluetooth 4.2, microUSB",
      weight: "196g",
      dimensions: "164.8 x 76.3 x 8.9 mm"
    },
    images: [img("infinix", "smart-6", 1), img("infinix", "smart-6", 2), img("infinix", "smart-6", 3)],
    colors: [{ name: "Midnight Black", hex: "#121212" }, { name: "Aqua Blue", hex: "#00bfff" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Zero Ultra", year: 2022,
    price: 420000, originalPrice: 480000,
    description: "Infinix Zero Ultra features a revolutionary 200MP camera, curved AMOLED display, and 180W Thunder Charge.",
    specifications: {
      display: "6.8\" FHD+ Curved AMOLED, 120Hz, 1500 nits",
      processor: "MediaTek Dimensity 920 5G (6nm)",
      ram: "8GB LPDDR5",
      storage: "256GB UFS 3.1",
      camera: "200MP Main + 13MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "4500mAh, 180W Thunder Charge",
      os: "Android 12, XOS 12",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.2, USB-C",
      weight: "198g",
      dimensions: "163.5 x 75.5 x 8.8 mm"
    },
    images: [img("infinix", "zero-ultra", 1), img("infinix", "zero-ultra", 2), img("infinix", "zero-ultra", 3)],
    colors: [{ name: "Coslight Silver", hex: "#e8e8e8" }, { name: "Genesis Noir", hex: "#0d0d0d" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },

  // ==================== INFINIX 2023 ====================
  {
    brand: "Infinix", model: "Note 30 Pro", year: 2023,
    price: 310000, originalPrice: 350000,
    description: "Infinix Note 30 Pro brings flagship features with 68W fast charging, 108MP camera, and vibrant AMOLED display.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 120Hz, 10-bit, 1300 nits",
      processor: "MediaTek Helio G99 Ultimate (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "256GB UFS 2.2",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 68W Fast Charge + Reverse Charging",
      os: "Android 13, XOS 13",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C OTG",
      weight: "195g",
      dimensions: "164.5 x 76.8 x 8.5 mm"
    },
    images: [img("infinix", "note-30-pro", 1), img("infinix", "note-30-pro", 2), img("infinix", "note-30-pro", 3)],
    colors: [{ name: "Obsidian Black", hex: "#0b0b0b" }, { name: "Interstellar Blue", hex: "#1e3a5f" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Infinix", model: "GT 10 Pro", year: 2023,
    price: 340000, originalPrice: 380000,
    description: "Built for gamers, the Infinix GT 10 Pro features Dimensity 8050, 120Hz AMOLED, and aggressive cyberpunk design.",
    specifications: {
      display: "6.67\" FHD+ AMOLED, 120Hz, 10-bit, 1300 nits",
      processor: "MediaTek Dimensity 8050 5G (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "256GB UFS 3.1",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 45W Fast Charging",
      os: "Android 13, XOS 13 with GT Mode",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.2, USB-C",
      weight: "205g",
      dimensions: "163.2 x 75.5 x 8.7 mm"
    },
    images: [img("infinix", "gt-10-pro", 1), img("infinix", "gt-10-pro", 2), img("infinix", "gt-10-pro", 3)],
    colors: [{ name: "Cyber Black", hex: "#050505" }, { name: "Mecha Silver", hex: "#dcdcdc" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Zero 30 5G", year: 2023,
    price: 380000, originalPrice: 430000,
    description: "Infinix Zero 30 5G offers flagship-level performance with Dimensity 8020, 144Hz AMOLED, and 108MP camera.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 144Hz, 10-bit, 1500 nits",
      processor: "MediaTek Dimensity 8020 5G (6nm)",
      ram: "12GB LPDDR5 + 12GB Extended",
      storage: "256GB UFS 3.1",
      camera: "108MP Main + 13MP Ultrawide + 2MP Macro, 50MP Front",
      battery: "5000mAh, 68W Fast Charging",
      os: "Android 13, XOS 13",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.2, USB-C",
      weight: "196g",
      dimensions: "164.5 x 74.8 x 8.0 mm"
    },
    images: [img("infinix", "zero-30-5g", 1), img("infinix", "zero-30-5g", 2), img("infinix", "zero-30-5g", 3)],
    colors: [{ name: "Rome Green", hex: "#2d4a3e" }, { name: "Dune Gold", hex: "#c9a961" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Hot 30", year: 2023,
    price: 145000, originalPrice: 165000,
    description: "Infinix Hot 30 offers excellent value with a 90Hz display, Helio G88 processor, and 50MP camera system.",
    specifications: {
      display: "6.78\" HD+ IPS LCD, 90Hz, 500 nits",
      processor: "MediaTek Helio G88 (12nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "128GB eMMC 5.1",
      camera: "50MP Main + 2MP Depth + AI Lens, 8MP Front",
      battery: "5000mAh, 18W Fast Charging",
      os: "Android 13, XOS 12.6",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C",
      weight: "199g",
      dimensions: "168.0 x 77.8 x 8.3 mm"
    },
    images: [img("infinix", "hot-30", 1), img("infinix", "hot-30", 2), img("infinix", "hot-30", 3)],
    colors: [{ name: "Battlegreen", hex: "#355e3b" }, { name: "Racing Black", hex: "#0a0a0a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Infinix", model: "Smart 7", year: 2023,
    price: 105000, originalPrice: 120000,
    description: "The Infinix Smart 7 is a budget-friendly smartphone with a large display, improved performance, and reliable battery life.",
    specifications: {
      display: "6.6\" HD+ IPS LCD, 60Hz",
      processor: "Unisoc SC9863A1 (28nm)",
      ram: "4GB LPDDR3 + 4GB Extended",
      storage: "64GB eMMC",
      camera: "13MP Main + 2MP Depth, 5MP Front",
      battery: "5000mAh, 10W Charging",
      os: "Android 12 (Go edition)",
      connectivity: "4G LTE, Wi-Fi, Bluetooth 4.2, microUSB",
      weight: "195g",
      dimensions: "164.0 x 76.0 x 8.7 mm"
    },
    images: [img("infinix", "smart-7", 1), img("infinix", "smart-7", 2), img("infinix", "smart-7", 3)],
    colors: [{ name: "Noir Black", hex: "#101010" }, { name: "Sky Blue", hex: "#87ceeb" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },

  // ==================== INFINIX 2024 ====================
  {
    brand: "Infinix", model: "Zero Flip", year: 2024,
    price: 650000, originalPrice: 720000,
    description: "Infinix's first foldable phone! The Zero Flip features a stunning LTPO AMOLED foldable display, flagship processor, and premium design.",
    specifications: {
      display: "6.9\" LTPO AMOLED Foldable, 120Hz, 2600 nits peak",
      processor: "MediaTek Dimensity 8020 5G (6nm)",
      ram: "8GB LPDDR5 + 8GB Extended",
      storage: "512GB UFS 3.1",
      camera: "50MP Main + 13MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "4000mAh, 45W Fast Charging",
      os: "Android 14, XOS 14",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, USB-C",
      weight: "195g",
      dimensions: "Unfolded: 165.0 x 75.0 x 7.2 mm"
    },
    images: [img("infinix", "zero-flip", 1), img("infinix", "zero-flip", 2), img("infinix", "zero-flip", 3)],
    colors: [{ name: "Dream Purple", hex: "#9370db" }, { name: "Elegant Black", hex: "#0a0a0a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Note 40 Pro", year: 2024,
    price: 340000, originalPrice: 380000,
    description: "Infinix Note 40 Pro introduces 45W wireless charging, 108MP camera, and a stunning 120Hz AMOLED display.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 120Hz, 10-bit, 1500 nits",
      processor: "MediaTek Helio G99 Ultimate (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "256GB UFS 2.2",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 70W Wired + 45W Wireless Charging",
      os: "Android 14, XOS 14",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C OTG",
      weight: "199g",
      dimensions: "164.3 x 76.5 x 8.4 mm"
    },
    images: [img("infinix", "note-40-pro", 1), img("infinix", "note-40-pro", 2), img("infinix", "note-40-pro", 3)],
    colors: [{ name: "Obsidian Black", hex: "#080808" }, { name: "Titan Gold", hex: "#b8860b" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Zero 30 4G", year: 2024,
    price: 290000, originalPrice: 330000,
    description: "The Zero 30 4G variant brings the same stunning 144Hz AMOLED display and 108MP camera with Helio G99 power.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 144Hz, 10-bit, 1500 nits",
      processor: "MediaTek Helio G99 (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "256GB UFS 2.2",
      camera: "108MP Main + 13MP Ultrawide + 2MP Macro, 50MP Front",
      battery: "5000mAh, 68W Fast Charging",
      os: "Android 14, XOS 14",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C",
      weight: "194g",
      dimensions: "164.5 x 74.8 x 8.0 mm"
    },
    images: [img("infinix", "zero-30-4g", 1), img("infinix", "zero-30-4g", 2), img("infinix", "zero-30-4g", 3)],
    colors: [{ name: "Wilderness Green", hex: "#2e4a3a" }, { name: "Flash Black", hex: "#0a0a0a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Infinix", model: "GT 20 Pro", year: 2024,
    price: 380000, originalPrice: 430000,
    description: "The ultimate gaming phone with Dimensity 8200 Ultimate, 144Hz AMOLED, and RGB lighting effects.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 144Hz, 10-bit, 1600 nits",
      processor: "MediaTek Dimensity 8200 Ultimate 5G (4nm)",
      ram: "12GB LPDDR5 + 12GB Extended",
      storage: "256GB UFS 3.1",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 110W Ultra Fast Charging",
      os: "Android 14, XOS 14 with GT Mode 4.0",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, USB-C",
      weight: "202g",
      dimensions: "163.5 x 75.5 x 8.5 mm"
    },
    images: [img("infinix", "gt-20-pro", 1), img("infinix", "gt-20-pro", 2), img("infinix", "gt-20-pro", 3)],
    colors: [{ name: "Wake Orange", hex: "#ff6b35" }, { name: "Meteorite Black", hex: "#050505" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Hot 40 Pro", year: 2024,
    price: 195000, originalPrice: 220000,
    description: "Infinix Hot 40 Pro brings 108MP camera and 120Hz display to the mid-range segment with Helio G99 performance.",
    specifications: {
      display: "6.78\" FHD+ IPS LCD, 120Hz, 550 nits",
      processor: "MediaTek Helio G99 (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "256GB UFS 2.2",
      camera: "108MP Main + 2MP Depth + 2MP Macro, 32MP Front",
      battery: "5000mAh, 33W Fast Charging",
      os: "Android 14, XOS 14",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C",
      weight: "199g",
      dimensions: "168.2 x 77.8 x 8.2 mm"
    },
    images: [img("infinix", "hot-40-pro", 1), img("infinix", "hot-40-pro", 2), img("infinix", "hot-40-pro", 3)],
    colors: [{ name: "Starry Black", hex: "#0a0a14" }, { name: "Sage Green", hex: "#9caf88" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },

  // ==================== INFINIX 2025 ====================
  {
    brand: "Infinix", model: "Note 40 5G Racing Edition", year: 2025,
    price: 320000, originalPrice: 360000,
    description: "Special Racing Edition with Dimensity 7020 5G, motorsport-inspired design, and enhanced performance features.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 120Hz, 10-bit, 1500 nits",
      processor: "MediaTek Dimensity 7020 5G (6nm)",
      ram: "12GB + 12GB Extended RAM",
      storage: "256GB UFS 3.1",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 70W Fast Charging",
      os: "Android 14, XOS 14 Racing Edition",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.2, USB-C",
      weight: "197g",
      dimensions: "164.3 x 76.5 x 8.4 mm"
    },
    images: [img("infinix", "note-40-5g-racing", 1), img("infinix", "note-40-5g-racing", 2), img("infinix", "note-40-5g-racing", 3)],
    colors: [{ name: "Racing Red", hex: "#dc143c" }, { name: "Carbon Black", hex: "#0d0d0d" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Hot 50", year: 2025,
    price: 165000, originalPrice: 185000,
    description: "Infinix Hot 50 features the new Helio G100 processor, 120Hz LTPS display, and improved 50MP camera system.",
    specifications: {
      display: "6.78\" HD+ LTPS LCD, 120Hz, 550 nits",
      processor: "MediaTek Helio G100 (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "128GB UFS 2.2",
      camera: "50MP Main + 2MP Depth + AI Lens, 16MP Front",
      battery: "5000mAh, 33W Fast Charging",
      os: "Android 15, XOS 15",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.1, USB-C",
      weight: "196g",
      dimensions: "168.0 x 77.8 x 8.1 mm"
    },
    images: [img("infinix", "hot-50", 1), img("infinix", "hot-50", 2), img("infinix", "hot-50", 3)],
    colors: [{ name: "Ocean Blue", hex: "#006994" }, { name: "Midnight Black", hex: "#101010" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Zero 40 5G", year: 2025,
    price: 420000, originalPrice: 470000,
    description: "Flagship performance with Dimensity 8200, stunning 144Hz AMOLED, and pro-grade 108MP camera system.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 144Hz, 10-bit, 1800 nits",
      processor: "MediaTek Dimensity 8200 5G (4nm)",
      ram: "12GB LPDDR5 + 12GB Extended",
      storage: "256GB UFS 3.1",
      camera: "108MP Main + 13MP Ultrawide + 8MP Telephoto, 50MP Front",
      battery: "5000mAh, 100W Fast Charging",
      os: "Android 15, XOS 15",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "193g",
      dimensions: "164.0 x 74.5 x 7.9 mm"
    },
    images: [img("infinix", "zero-40-5g", 1), img("infinix", "zero-40-5g", 2), img("infinix", "zero-40-5g", 3)],
    colors: [{ name: "Alpine Green", hex: "#2e5a3e" }, { name: "Lunar Silver", hex: "#c0c0c0" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "GT 30 Pro", year: 2025,
    price: 450000, originalPrice: 500000,
    description: "Next-gen gaming flagship with Dimensity 8350, 144Hz AMOLED, and massive 12GB/512GB configuration.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 144Hz, 10-bit, 1800 nits",
      processor: "MediaTek Dimensity 8350 5G (4nm)",
      ram: "12GB LPDDR5X + 12GB Extended",
      storage: "512GB UFS 4.0",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 120W Ultra Fast Charging",
      os: "Android 15, XOS 15 with GT Mode 5.0",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C 3.2",
      weight: "200g",
      dimensions: "163.5 x 75.5 x 8.3 mm"
    },
    images: [img("infinix", "gt-30-pro", 1), img("infinix", "gt-30-pro", 2), img("infinix", "gt-30-pro", 3)],
    colors: [{ name: "Nitro Blue", hex: "#1e40af" }, { name: "Phantom Black", hex: "#050505" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Smart 9", year: 2025,
    price: 115000, originalPrice: 130000,
    description: "The Smart 9 brings 120Hz display and Unisoc T606 performance to the budget segment.",
    specifications: {
      display: "6.7\" HD+ IPS LCD, 120Hz",
      processor: "Unisoc T606 (12nm)",
      ram: "4GB + 4GB Extended RAM",
      storage: "128GB eMMC 5.1",
      camera: "13MP Main + 2MP Depth, 8MP Front",
      battery: "5000mAh, 18W Fast Charging",
      os: "Android 14 (Go edition)",
      connectivity: "4G LTE, Wi-Fi 5, Bluetooth 5.0, USB-C",
      weight: "192g",
      dimensions: "164.5 x 76.0 x 8.5 mm"
    },
    images: [img("infinix", "smart-9", 1), img("infinix", "smart-9", 2), img("infinix", "smart-9", 3)],
    colors: [{ name: "Classic Black", hex: "#121212" }, { name: "Blush Gold", hex: "#d4af37" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },

  // ==================== INFINIX 2026 ====================
  {
    brand: "Infinix", model: "Hot 70 Pro 5G+", year: 2026,
    price: 220000, originalPrice: 250000,
    description: "The Hot 70 Pro 5G+ brings 5G connectivity, Dimensity 7025, and 108MP camera to the affordable segment.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 120Hz, 10-bit, 1300 nits",
      processor: "MediaTek Dimensity 7025 5G (6nm)",
      ram: "8GB + 8GB Extended RAM",
      storage: "256GB UFS 2.2",
      camera: "108MP Main + 8MP Ultrawide + 2MP Macro, 32MP Front",
      battery: "5000mAh, 45W Fast Charging",
      os: "Android 16, XOS 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.2, USB-C",
      weight: "194g",
      dimensions: "168.0 x 77.8 x 8.0 mm"
    },
    images: [img("infinix", "hot-70-pro-5g", 1), img("infinix", "hot-70-pro-5g", 2), img("infinix", "hot-70-pro-5g", 3)],
    colors: [{ name: "Emerald Green", hex: "#046307" }, { name: "Cosmic Black", hex: "#0a0a14" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Note 50X 5G", year: 2026,
    price: 360000, originalPrice: 400000,
    description: "Note 50X 5G features powerful Dimensity 7300, 12GB RAM, and pro-grade 108MP camera system.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 120Hz, 10-bit, 1600 nits",
      processor: "MediaTek Dimensity 7300 5G (4nm)",
      ram: "12GB + 12GB Extended RAM",
      storage: "256GB UFS 3.1",
      camera: "108MP Main + 13MP Ultrawide + 5MP Telephoto, 32MP Front",
      battery: "5200mAh, 80W Fast Charging",
      os: "Android 16, XOS 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "196g",
      dimensions: "164.3 x 76.5 x 8.2 mm"
    },
    images: [img("infinix", "note-50x-5g", 1), img("infinix", "note-50x-5g", 2), img("infinix", "note-50x-5g", 3)],
    colors: [{ name: "Titanium Black", hex: "#080808" }, { name: "Desert Gold", hex: "#c9a961" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Zero Flip 2", year: 2026,
    price: 750000, originalPrice: 820000,
    description: "Second-generation foldable with improved hinge, Dimensity 8400 flagship chip, and enhanced camera system.",
    specifications: {
      display: "6.9\" LTPO AMOLED Foldable, 120Hz, 2800 nits peak",
      processor: "MediaTek Dimensity 8400 5G (3nm)",
      ram: "12GB LPDDR5X + 12GB Extended",
      storage: "512GB UFS 4.0",
      camera: "50MP Main + 13MP Ultrawide + 8MP Telephoto, 32MP Front",
      battery: "4200mAh, 65W Fast Charging",
      os: "Android 16, XOS 16 Fold Edition",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "188g",
      dimensions: "Unfolded: 164.0 x 74.5 x 6.8 mm"
    },
    images: [img("infinix", "zero-flip-2", 1), img("infinix", "zero-flip-2", 2), img("infinix", "zero-flip-2", 3)],
    colors: [{ name: "Galaxy Purple", hex: "#6a0dad" }, { name: "Ceramic White", hex: "#f5f5f5" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "GT 50 Pro", year: 2026,
    price: 520000, originalPrice: 580000,
    description: "Ultimate gaming flagship with Snapdragon 7s Gen 4, 144Hz AMOLED, and massive 512GB storage.",
    specifications: {
      display: "6.78\" FHD+ AMOLED, 144Hz, 10-bit, 2000 nits",
      processor: "Qualcomm Snapdragon 7s Gen 4 (4nm)",
      ram: "12GB LPDDR5X + 12GB Extended",
      storage: "512GB UFS 4.0",
      camera: "108MP Main + 13MP Ultrawide + 5MP Telephoto, 32MP Front",
      battery: "5200mAh, 120W Ultra Fast Charging",
      os: "Android 16, XOS 16 with GT Mode 6.0",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "198g",
      dimensions: "163.5 x 75.5 x 8.1 mm"
    },
    images: [img("infinix", "gt-50-pro", 1), img("infinix", "gt-50-pro", 2), img("infinix", "gt-50-pro", 3)],
    colors: [{ name: "Velocity Red", hex: "#cc0000" }, { name: "Stealth Black", hex: "#030303" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Infinix", model: "Zero 50 5G", year: 2026,
    price: 480000, originalPrice: 540000,
    description: "The new Zero flagship features Dimensity 8300, stunning 200MP camera, and premium glass-metal design.",
    specifications: {
      display: "6.78\" LTPO AMOLED, 144Hz, 10-bit, 2200 nits",
      processor: "MediaTek Dimensity 8300 5G (4nm)",
      ram: "12GB LPDDR5X + 12GB Extended",
      storage: "256GB UFS 4.0",
      camera: "200MP Main + 13MP Ultrawide + 8MP Telephoto 3x, 50MP Front",
      battery: "5000mAh, 100W Fast + 50W Wireless",
      os: "Android 16, XOS 16",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "191g",
      dimensions: "163.8 x 74.2 x 7.8 mm"
    },
    images: [img("infinix", "zero-50-5g", 1), img("infinix", "zero-50-5g", 2), img("infinix", "zero-50-5g", 3)],
    colors: [{ name: "Titanium Gray", hex: "#696969" }, { name: "Aurora Blue", hex: "#1e90ff" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },

  // ==================== APPLE iPHONE 2022 ====================
  {
    brand: "Apple", model: "iPhone 14 Pro Max", year: 2022,
    price: 1450000, originalPrice: 1600000,
    description: "iPhone 14 Pro Max features the revolutionary A16 Bionic chip, Dynamic Island, 48MP main camera, and always-on display.",
    specifications: {
      display: "6.7\" Super Retina XDR, ProMotion 120Hz, Always-On, 2000 nits",
      processor: "Apple A16 Bionic (4nm)",
      ram: "6GB LPDDR5",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 3x, 12MP TrueDepth Front",
      battery: "4323mAh, 27W Wired + 15W MagSafe Wireless",
      os: "iOS 16, upgradable to iOS 18",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, Lightning",
      weight: "240g",
      dimensions: "160.7 x 77.6 x 7.85 mm"
    },
    images: [img("apple", "iphone-14-pro-max", 1), img("apple", "iphone-14-pro-max", 2), img("apple", "iphone-14-pro-max", 3)],
    colors: [{ name: "Deep Purple", hex: "#5c4d7d" }, { name: "Gold", hex: "#d4af37" }, { name: "Silver", hex: "#c0c0c0" }, { name: "Space Black", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 14 Pro", year: 2022,
    price: 1250000, originalPrice: 1400000,
    description: "iPhone 14 Pro brings Dynamic Island, A16 Bionic, and pro camera system in a compact 6.1-inch form factor.",
    specifications: {
      display: "6.1\" Super Retina XDR, ProMotion 120Hz, Always-On, 2000 nits",
      processor: "Apple A16 Bionic (4nm)",
      ram: "6GB LPDDR5",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 3x, 12MP TrueDepth Front",
      battery: "3200mAh, 23W Wired + 15W MagSafe",
      os: "iOS 16, upgradable to iOS 18",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, Lightning",
      weight: "206g",
      dimensions: "147.5 x 71.5 x 7.85 mm"
    },
    images: [img("apple", "iphone-14-pro", 1), img("apple", "iphone-14-pro", 2), img("apple", "iphone-14-pro", 3)],
    colors: [{ name: "Deep Purple", hex: "#5c4d7d" }, { name: "Gold", hex: "#d4af37" }, { name: "Silver", hex: "#c0c0c0" }, { name: "Space Black", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 14 Plus", year: 2022,
    price: 980000, originalPrice: 1100000,
    description: "iPhone 14 Plus offers the large 6.7-inch display experience with A15 Bionic performance and excellent battery life.",
    specifications: {
      display: "6.7\" Super Retina XDR, 60Hz, 1200 nits",
      processor: "Apple A15 Bionic (5nm)",
      ram: "6GB LPDDR4X",
      storage: "512GB NVMe",
      camera: "12MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "4325mAh, 27W Wired + 15W MagSafe",
      os: "iOS 16, upgradable to iOS 18",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, Lightning",
      weight: "203g",
      dimensions: "160.8 x 78.1 x 7.8 mm"
    },
    images: [img("apple", "iphone-14-plus", 1), img("apple", "iphone-14-plus", 2), img("apple", "iphone-14-plus", 3)],
    colors: [{ name: "Midnight", hex: "#1a1a2e" }, { name: "Purple", hex: "#b19cd9" }, { name: "Blue", hex: "#4169e1" }, { name: "Yellow", hex: "#ffd700" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 14", year: 2022,
    price: 820000, originalPrice: 920000,
    description: "iPhone 14 features A15 Bionic, improved dual-camera system, Crash Detection, and Emergency SOS via satellite.",
    specifications: {
      display: "6.1\" Super Retina XDR, 60Hz, 1200 nits",
      processor: "Apple A15 Bionic (5nm)",
      ram: "6GB LPDDR4X",
      storage: "512GB NVMe",
      camera: "12MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "3279mAh, 23W Wired + 15W MagSafe",
      os: "iOS 16, upgradable to iOS 18",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, Lightning",
      weight: "172g",
      dimensions: "146.7 x 71.5 x 7.8 mm"
    },
    images: [img("apple", "iphone-14", 1), img("apple", "iphone-14", 2), img("apple", "iphone-14", 3)],
    colors: [{ name: "Midnight", hex: "#1a1a2e" }, { name: "Purple", hex: "#b19cd9" }, { name: "Blue", hex: "#4169e1" }, { name: "Yellow", hex: "#ffd700" }, { name: "Red", hex: "#dc143c" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone SE (2022)", year: 2022,
    price: 480000, originalPrice: 550000,
    description: "iPhone SE (3rd generation) combines A15 Bionic power with the classic Touch ID home button design.",
    specifications: {
      display: "4.7\" Retina HD LCD, 60Hz, 625 nits",
      processor: "Apple A15 Bionic (5nm)",
      ram: "4GB LPDDR4X",
      storage: "256GB NVMe",
      camera: "12MP Main, 7MP Front",
      battery: "2018mAh, 20W Wired + 15W MagSafe",
      os: "iOS 15, upgradable to iOS 18",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.0, Lightning",
      weight: "144g",
      dimensions: "138.4 x 67.3 x 7.3 mm"
    },
    images: [img("apple", "iphone-se-2022", 1), img("apple", "iphone-se-2022", 2), img("apple", "iphone-se-2022", 3)],
    colors: [{ name: "Midnight", hex: "#1a1a2e" }, { name: "Starlight", hex: "#f5f5dc" }, { name: "Red", hex: "#dc143c" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },

  // ==================== APPLE iPHONE 2023 ====================
  {
    brand: "Apple", model: "iPhone 15 Pro Max", year: 2023,
    price: 1750000, originalPrice: 1950000,
    description: "iPhone 15 Pro Max features titanium design, A17 Pro chip, 5x telephoto camera, and USB-C with USB 3 speeds.",
    specifications: {
      display: "6.7\" Super Retina XDR, ProMotion 120Hz, Always-On, 2000 nits",
      processor: "Apple A17 Pro (3nm)",
      ram: "8GB LPDDR5",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 5x, 12MP TrueDepth Front",
      battery: "4441mAh, 27W Wired + 15W MagSafe",
      os: "iOS 17, upgradable to iOS 19",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C 3.0",
      weight: "221g",
      dimensions: "159.9 x 76.7 x 8.25 mm"
    },
    images: [img("apple", "iphone-15-pro-max", 1), img("apple", "iphone-15-pro-max", 2), img("apple", "iphone-15-pro-max", 3)],
    colors: [{ name: "Natural Titanium", hex: "#c0c0c0" }, { name: "Blue Titanium", hex: "#4682b4" }, { name: "White Titanium", hex: "#f5f5f5" }, { name: "Black Titanium", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 15 Pro", year: 2023,
    price: 1500000, originalPrice: 1680000,
    description: "iPhone 15 Pro brings titanium design, A17 Pro, Action button, and USB-C to the pro lineup.",
    specifications: {
      display: "6.1\" Super Retina XDR, ProMotion 120Hz, Always-On, 2000 nits",
      processor: "Apple A17 Pro (3nm)",
      ram: "8GB LPDDR5",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 3x, 12MP TrueDepth Front",
      battery: "3274mAh, 23W Wired + 15W MagSafe",
      os: "iOS 17, upgradable to iOS 19",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C 3.0",
      weight: "187g",
      dimensions: "146.6 x 70.6 x 8.25 mm"
    },
    images: [img("apple", "iphone-15-pro", 1), img("apple", "iphone-15-pro", 2), img("apple", "iphone-15-pro", 3)],
    colors: [{ name: "Natural Titanium", hex: "#c0c0c0" }, { name: "Blue Titanium", hex: "#4682b4" }, { name: "White Titanium", hex: "#f5f5f5" }, { name: "Black Titanium", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 15 Plus", year: 2023,
    price: 1100000, originalPrice: 1250000,
    description: "iPhone 15 Plus features Dynamic Island, 48MP main camera, USB-C, and A16 Bionic in a large 6.7-inch package.",
    specifications: {
      display: "6.7\" Super Retina XDR, 60Hz, 2000 nits peak",
      processor: "Apple A16 Bionic (4nm)",
      ram: "6GB LPDDR5",
      storage: "512GB NVMe",
      camera: "48MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "4383mAh, 27W Wired + 15W MagSafe",
      os: "iOS 17, upgradable to iOS 19",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, USB-C 2.0",
      weight: "201g",
      dimensions: "160.9 x 77.8 x 7.8 mm"
    },
    images: [img("apple", "iphone-15-plus", 1), img("apple", "iphone-15-plus", 2), img("apple", "iphone-15-plus", 3)],
    colors: [{ name: "Black", hex: "#000000" }, { name: "Blue", hex: "#4169e1" }, { name: "Green", hex: "#228b22" }, { name: "Yellow", hex: "#ffd700" }, { name: "Pink", hex: "#ffc0cb" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 15", year: 2023,
    price: 920000, originalPrice: 1050000,
    description: "iPhone 15 introduces Dynamic Island, 48MP camera, USB-C, and vibrant new colors with A16 Bionic performance.",
    specifications: {
      display: "6.1\" Super Retina XDR, 60Hz, 2000 nits peak",
      processor: "Apple A16 Bionic (4nm)",
      ram: "6GB LPDDR5",
      storage: "512GB NVMe",
      camera: "48MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "3349mAh, 23W Wired + 15W MagSafe",
      os: "iOS 17, upgradable to iOS 19",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.3, USB-C 2.0",
      weight: "171g",
      dimensions: "147.6 x 71.6 x 7.8 mm"
    },
    images: [img("apple", "iphone-15", 1), img("apple", "iphone-15", 2), img("apple", "iphone-15", 3)],
    colors: [{ name: "Black", hex: "#000000" }, { name: "Blue", hex: "#4169e1" }, { name: "Green", hex: "#228b22" }, { name: "Yellow", hex: "#ffd700" }, { name: "Pink", hex: "#ffc0cb" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Apple", model: "iPhone 13", year: 2023,
    price: 650000, originalPrice: 750000,
    description: "iPhone 13 remains an excellent choice with A15 Bionic, excellent dual cameras, and all-day battery life.",
    specifications: {
      display: "6.1\" Super Retina XDR, 60Hz, 1200 nits",
      processor: "Apple A15 Bionic (5nm)",
      ram: "4GB LPDDR4X",
      storage: "512GB NVMe",
      camera: "12MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "3240mAh, 20W Wired + 15W MagSafe",
      os: "iOS 15, upgradable to iOS 19",
      connectivity: "5G, 4G LTE, Wi-Fi 6, Bluetooth 5.0, Lightning",
      weight: "174g",
      dimensions: "146.7 x 71.5 x 7.65 mm"
    },
    images: [img("apple", "iphone-13", 1), img("apple", "iphone-13", 2), img("apple", "iphone-13", 3)],
    colors: [{ name: "Midnight", hex: "#1a1a2e" }, { name: "Starlight", hex: "#f5f5dc" }, { name: "Blue", hex: "#4169e1" }, { name: "Red", hex: "#dc143c" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },

  // ==================== APPLE iPHONE 2024 ====================
  {
    brand: "Apple", model: "iPhone 16 Pro Max", year: 2024,
    price: 2100000, originalPrice: 2350000,
    description: "iPhone 16 Pro Max features the powerful A18 Pro chip, 6.9-inch display, Camera Control button, and Apple Intelligence.",
    specifications: {
      display: "6.9\" Super Retina XDR, ProMotion 120Hz, Always-On, 2500 nits",
      processor: "Apple A18 Pro (3nm)",
      ram: "8GB LPDDR5X",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 5x, 12MP TrueDepth Front",
      battery: "4685mAh, 35W Wired + 20W MagSafe",
      os: "iOS 18 with Apple Intelligence",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "227g",
      dimensions: "163.0 x 77.6 x 8.25 mm"
    },
    images: [img("apple", "iphone-16-pro-max", 1), img("apple", "iphone-16-pro-max", 2), img("apple", "iphone-16-pro-max", 3)],
    colors: [{ name: "Natural Titanium", hex: "#c0c0c0" }, { name: "Desert Titanium", hex: "#c9a961" }, { name: "White Titanium", hex: "#f5f5f5" }, { name: "Black Titanium", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 16 Pro", year: 2024,
    price: 1800000, originalPrice: 2000000,
    description: "iPhone 16 Pro introduces Camera Control, A18 Pro, larger 6.3-inch display, and Apple Intelligence features.",
    specifications: {
      display: "6.3\" Super Retina XDR, ProMotion 120Hz, Always-On, 2500 nits",
      processor: "Apple A18 Pro (3nm)",
      ram: "8GB LPDDR5X",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 3x, 12MP TrueDepth Front",
      battery: "3582mAh, 27W Wired + 20W MagSafe",
      os: "iOS 18 with Apple Intelligence",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "194g",
      dimensions: "149.6 x 71.5 x 8.25 mm"
    },
    images: [img("apple", "iphone-16-pro", 1), img("apple", "iphone-16-pro", 2), img("apple", "iphone-16-pro", 3)],
    colors: [{ name: "Natural Titanium", hex: "#c0c0c0" }, { name: "Desert Titanium", hex: "#c9a961" }, { name: "White Titanium", hex: "#f5f5f5" }, { name: "Black Titanium", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 16 Plus", year: 2024,
    price: 1250000, originalPrice: 1400000,
    description: "iPhone 16 Plus features A18 chip, Camera Control button, larger display, and USB-C with Apple Intelligence support.",
    specifications: {
      display: "6.7\" Super Retina XDR, 60Hz, 2500 nits peak",
      processor: "Apple A18 (3nm)",
      ram: "8GB LPDDR5",
      storage: "512GB NVMe",
      camera: "48MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "4557mAh, 27W Wired + 15W MagSafe",
      os: "iOS 18 with Apple Intelligence",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 2.0",
      weight: "199g",
      dimensions: "163.1 x 78.0 x 7.8 mm"
    },
    images: [img("apple", "iphone-16-plus", 1), img("apple", "iphone-16-plus", 2), img("apple", "iphone-16-plus", 3)],
    colors: [{ name: "Ultramarine", hex: "#0437f2" }, { name: "Teal", hex: "#008080" }, { name: "Pink", hex: "#ffc0cb" }, { name: "White", hex: "#ffffff" }, { name: "Black", hex: "#000000" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 16", year: 2024,
    price: 1050000, originalPrice: 1180000,
    description: "iPhone 16 features A18 chip, Camera Control button, vertical camera design, and Apple Intelligence capabilities.",
    specifications: {
      display: "6.1\" Super Retina XDR, 60Hz, 2500 nits peak",
      processor: "Apple A18 (3nm)",
      ram: "8GB LPDDR5",
      storage: "512GB NVMe",
      camera: "48MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "3561mAh, 23W Wired + 15W MagSafe",
      os: "iOS 18 with Apple Intelligence",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 2.0",
      weight: "170g",
      dimensions: "147.6 x 71.6 x 7.8 mm"
    },
    images: [img("apple", "iphone-16", 1), img("apple", "iphone-16", 2), img("apple", "iphone-16", 3)],
    colors: [{ name: "Ultramarine", hex: "#0437f2" }, { name: "Teal", hex: "#008080" }, { name: "Pink", hex: "#ffc0cb" }, { name: "White", hex: "#ffffff" }, { name: "Black", hex: "#000000" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 16e", year: 2024,
    price: 720000, originalPrice: 820000,
    description: "iPhone 16e brings A18 performance and Apple Intelligence at a more affordable price point with single camera system.",
    specifications: {
      display: "6.1\" Super Retina XDR, 60Hz, 2000 nits peak",
      processor: "Apple A18 (3nm)",
      ram: "8GB LPDDR5",
      storage: "512GB NVMe",
      camera: "48MP Main, 12MP TrueDepth Front",
      battery: "3400mAh, 20W Wired + 15W MagSafe",
      os: "iOS 18 with Apple Intelligence",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 2.0",
      weight: "162g",
      dimensions: "147.0 x 71.0 x 7.6 mm"
    },
    images: [img("apple", "iphone-16e", 1), img("apple", "iphone-16e", 2), img("apple", "iphone-16e", 3)],
    colors: [{ name: "Black", hex: "#000000" }, { name: "White", hex: "#ffffff" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },

  // ==================== APPLE iPHONE 2025 ====================
  {
    brand: "Apple", model: "iPhone 17 Pro Max", year: 2025,
    price: 2450000, originalPrice: 2750000,
    description: "iPhone 17 Pro Max features A19 Pro chip, 12GB RAM, advanced LTPO display, and revolutionary quad-camera system.",
    specifications: {
      display: "6.9\" LTPO Super Retina XDR, ProMotion 120Hz, Always-On, 3000 nits",
      processor: "Apple A19 Pro (2nm)",
      ram: "12GB LPDDR5X",
      storage: "2TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 5x + 12MP Periscope 10x, 12MP TrueDepth Front",
      battery: "4800mAh, 45W Wired + 25W MagSafe",
      os: "iOS 19 with Apple Intelligence 2.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 4.0",
      weight: "225g",
      dimensions: "163.5 x 77.8 x 8.1 mm"
    },
    images: [img("apple", "iphone-17-pro-max", 1), img("apple", "iphone-17-pro-max", 2), img("apple", "iphone-17-pro-max", 3)],
    colors: [{ name: "Titanium Gray", hex: "#696969" }, { name: "Titanium Gold", hex: "#d4af37" }, { name: "Titanium Silver", hex: "#c0c0c0" }, { name: "Titanium Black", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 17 Pro", year: 2025,
    price: 2100000, originalPrice: 2350000,
    description: "iPhone 17 Pro brings A19 Pro power, 12GB RAM, and pro camera system in the compact 6.3-inch titanium design.",
    specifications: {
      display: "6.3\" LTPO Super Retina XDR, ProMotion 120Hz, Always-On, 3000 nits",
      processor: "Apple A19 Pro (2nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 3x, 12MP TrueDepth Front",
      battery: "3700mAh, 35W Wired + 25W MagSafe",
      os: "iOS 19 with Apple Intelligence 2.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 4.0",
      weight: "191g",
      dimensions: "150.0 x 71.8 x 8.1 mm"
    },
    images: [img("apple", "iphone-17-pro", 1), img("apple", "iphone-17-pro", 2), img("apple", "iphone-17-pro", 3)],
    colors: [{ name: "Titanium Gray", hex: "#696969" }, { name: "Titanium Gold", hex: "#d4af37" }, { name: "Titanium Silver", hex: "#c0c0c0" }, { name: "Titanium Black", hex: "#1a1a1a" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 17", year: 2025,
    price: 1200000, originalPrice: 1350000,
    description: "iPhone 17 features A19 chip, LTPO display, dual camera system, and full Apple Intelligence 2.0 support.",
    specifications: {
      display: "6.1\" LTPO Super Retina XDR, 120Hz, 2500 nits peak",
      processor: "Apple A19 (2nm)",
      ram: "8GB LPDDR5X",
      storage: "512GB NVMe",
      camera: "48MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "3650mAh, 30W Wired + 20W MagSafe",
      os: "iOS 19 with Apple Intelligence 2.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.0",
      weight: "168g",
      dimensions: "148.0 x 71.8 x 7.7 mm"
    },
    images: [img("apple", "iphone-17", 1), img("apple", "iphone-17", 2), img("apple", "iphone-17", 3)],
    colors: [{ name: "Starlight", hex: "#f5f5dc" }, { name: "Midnight", hex: "#1a1a2e" }, { name: "Product Red", hex: "#dc143c" }, { name: "Pacific Blue", hex: "#1a5276" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone Air", year: 2025,
    price: 1650000, originalPrice: 1850000,
    description: "iPhone Air is the thinnest iPhone ever, featuring A19 chip, ultra-light design, and premium single camera.",
    specifications: {
      display: "6.6\" LTPO Super Retina XDR, 120Hz, 2500 nits",
      processor: "Apple A19 (2nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB NVMe",
      camera: "48MP Main, 12MP TrueDepth Front",
      battery: "3800mAh, 30W Wired + 20W MagSafe",
      os: "iOS 19 with Apple Intelligence 2.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.0",
      weight: "152g",
      dimensions: "160.0 x 76.0 x 6.2 mm"
    },
    images: [img("apple", "iphone-air", 1), img("apple", "iphone-air", 2), img("apple", "iphone-air", 3)],
    colors: [{ name: "Starlight", hex: "#f5f5dc" }, { name: "Midnight", hex: "#1a1a2e" }, { name: "Sky Blue", hex: "#87ceeb" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 16e", year: 2025,
    price: 650000, originalPrice: 750000,
    description: "iPhone 16e carried over from 2024, offering A18 performance and Apple Intelligence at an accessible price.",
    specifications: {
      display: "6.1\" Super Retina XDR, 60Hz, 2000 nits peak",
      processor: "Apple A18 (3nm)",
      ram: "8GB LPDDR5",
      storage: "512GB NVMe",
      camera: "48MP Main, 12MP TrueDepth Front",
      battery: "3400mAh, 20W Wired + 15W MagSafe",
      os: "iOS 19 with Apple Intelligence 2.0",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C 2.0",
      weight: "162g",
      dimensions: "147.0 x 71.0 x 7.6 mm"
    },
    images: [img("apple", "iphone-16e-2025", 1), img("apple", "iphone-16e-2025", 2), img("apple", "iphone-16e-2025", 3)],
    colors: [{ name: "Black", hex: "#000000" }, { name: "White", hex: "#ffffff" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },

  // ==================== APPLE iPHONE 2026 ====================
  {
    brand: "Apple", model: "iPhone 18 Pro Max", year: 2026,
    price: 2800000, originalPrice: 3150000,
    description: "iPhone 18 Pro Max is the ultimate flagship with A20 Pro 2nm chip, 12GB RAM, and revolutionary quad-camera system.",
    specifications: {
      display: "6.9\" LTPO Super Retina XDR, ProMotion 120Hz, Always-On, 3500 nits",
      processor: "Apple A20 Pro (2nm)",
      ram: "12GB LPDDR6",
      storage: "2TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 5x + 12MP Depth Sensor, 12MP TrueDepth Front",
      battery: "5000mAh, 50W Wired + 30W MagSafe",
      os: "iOS 20 with Apple Intelligence 3.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "222g",
      dimensions: "163.8 x 78.0 x 8.0 mm"
    },
    images: [img("apple", "iphone-18-pro-max", 1), img("apple", "iphone-18-pro-max", 2), img("apple", "iphone-18-pro-max", 3)],
    colors: [{ name: "Titanium Black", hex: "#1a1a1a" }, { name: "Titanium White", hex: "#f5f5f5" }, { name: "Titanium Bronze", hex: "#cd7f32" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 18 Pro", year: 2026,
    price: 2400000, originalPrice: 2700000,
    description: "iPhone 18 Pro features A20 Pro chip, advanced camera system, and premium titanium design with Apple Intelligence 3.0.",
    specifications: {
      display: "6.3\" LTPO Super Retina XDR, ProMotion 120Hz, Always-On, 3500 nits",
      processor: "Apple A20 Pro (2nm)",
      ram: "12GB LPDDR6",
      storage: "1TB NVMe",
      camera: "48MP Main + 12MP Ultrawide + 12MP Telephoto 3x, 12MP TrueDepth Front",
      battery: "3850mAh, 40W Wired + 30W MagSafe",
      os: "iOS 20 with Apple Intelligence 3.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "188g",
      dimensions: "150.2 x 72.0 x 8.0 mm"
    },
    images: [img("apple", "iphone-18-pro", 1), img("apple", "iphone-18-pro", 2), img("apple", "iphone-18-pro", 3)],
    colors: [{ name: "Titanium Black", hex: "#1a1a1a" }, { name: "Titanium White", hex: "#f5f5f5" }, { name: "Titanium Bronze", hex: "#cd7f32" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 18", year: 2026,
    price: 1350000, originalPrice: 1520000,
    description: "iPhone 18 brings A20 chip, LTPO display, and full Apple Intelligence 3.0 support with dual camera system.",
    specifications: {
      display: "6.1\" LTPO Super Retina XDR, 120Hz, 3000 nits peak",
      processor: "Apple A20 (2nm)",
      ram: "8GB LPDDR6",
      storage: "512GB NVMe",
      camera: "48MP Main + 12MP Ultrawide, 12MP TrueDepth Front",
      battery: "3800mAh, 35W Wired + 25W MagSafe",
      os: "iOS 20 with Apple Intelligence 3.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 3.2",
      weight: "165g",
      dimensions: "148.2 x 72.0 x 7.6 mm"
    },
    images: [img("apple", "iphone-18", 1), img("apple", "iphone-18", 2), img("apple", "iphone-18", 3)],
    colors: [{ name: "Midnight", hex: "#1a1a2e" }, { name: "Starlight", hex: "#f5f5dc" }, { name: "Ocean Blue", hex: "#006994" }, { name: "Sunset Orange", hex: "#ff6b35" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone 17e", year: 2026,
    price: 780000, originalPrice: 880000,
    description: "iPhone 17e offers A19 performance and Apple Intelligence at an accessible price point.",
    specifications: {
      display: "6.1\" LTPO Super Retina XDR, 120Hz, 2500 nits peak",
      processor: "Apple A19 (2nm)",
      ram: "8GB LPDDR5X",
      storage: "512GB NVMe",
      camera: "48MP Main, 12MP TrueDepth Front",
      battery: "3500mAh, 25W Wired + 15W MagSafe",
      os: "iOS 20 with Apple Intelligence 3.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 3.0",
      weight: "158g",
      dimensions: "147.5 x 71.5 x 7.4 mm"
    },
    images: [img("apple", "iphone-17e", 1), img("apple", "iphone-17e", 2), img("apple", "iphone-17e", 3)],
    colors: [{ name: "Black", hex: "#000000" }, { name: "White", hex: "#ffffff" }, { name: "Purple", hex: "#9370db" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Apple", model: "iPhone Air 2", year: 2026,
    price: 1850000, originalPrice: 2080000,
    description: "iPhone Air 2 continues the ultra-thin legacy with A20 chip, improved cameras, and feather-light design.",
    specifications: {
      display: "6.6\" LTPO Super Retina XDR, 120Hz, 3000 nits",
      processor: "Apple A20 (2nm)",
      ram: "12GB LPDDR6",
      storage: "1TB NVMe",
      camera: "48MP Main, 12MP TrueDepth Front",
      battery: "3900mAh, 35W Wired + 25W MagSafe",
      os: "iOS 20 with Apple Intelligence 3.0",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 3.2",
      weight: "148g",
      dimensions: "160.2 x 76.2 x 5.9 mm"
    },
    images: [img("apple", "iphone-air-2", 1), img("apple", "iphone-air-2", 2), img("apple", "iphone-air-2", 3)],
    colors: [{ name: "Starlight", hex: "#f5f5dc" }, { name: "Midnight", hex: "#1a1a2e" }, { name: "Rose Gold", hex: "#b76e79" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },

  // ==================== SAMSUNG GALAXY 2022 ====================
  {
    brand: "Samsung", model: "Galaxy S22 Ultra 5G", year: 2022,
    price: 1150000, originalPrice: 1300000,
    description: "Galaxy S22 Ultra features Note design with built-in S Pen, Snapdragon 8 Gen 1, and 108MP quad camera system.",
    specifications: {
      display: "6.8\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 1750 nits",
      processor: "Qualcomm Snapdragon 8 Gen 1 (4nm)",
      ram: "12GB LPDDR5",
      storage: "1TB UFS 3.1",
      camera: "108MP Main + 12MP Ultrawide + 10MP Telephoto 3x + 10MP Telephoto 10x, 40MP Front",
      battery: "5000mAh, 45W Wired + 15W Wireless + 4.5W Reverse",
      os: "Android 12, One UI 4.1, upgradable to Android 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.2, USB-C",
      weight: "228g",
      dimensions: "163.3 x 77.9 x 8.9 mm"
    },
    images: [img("samsung", "galaxy-s22-ultra", 1), img("samsung", "galaxy-s22-ultra", 2), img("samsung", "galaxy-s22-ultra", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Burgundy", hex: "#800020" }, { name: "Green", hex: "#2e8b57" }, { name: "Phantom White", hex: "#f5f5f5" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy S22+ 5G", year: 2022,
    price: 850000, originalPrice: 980000,
    description: "Galaxy S22+ features Snapdragon 8 Gen 1, Dynamic AMOLED 2X display, and versatile triple camera system.",
    specifications: {
      display: "6.6\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 1750 nits",
      processor: "Qualcomm Snapdragon 8 Gen 1 (4nm)",
      ram: "8GB LPDDR5",
      storage: "256GB UFS 3.1",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 10MP Front",
      battery: "4500mAh, 45W Wired + 15W Wireless",
      os: "Android 12, One UI 4.1, upgradable to Android 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.2, USB-C",
      weight: "195g",
      dimensions: "157.4 x 75.8 x 7.6 mm"
    },
    images: [img("samsung", "galaxy-s22-plus", 1), img("samsung", "galaxy-s22-plus", 2), img("samsung", "galaxy-s22-plus", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Phantom White", hex: "#f5f5f5" }, { name: "Green", hex: "#2e8b57" }, { name: "Pink Gold", hex: "#e8b4b8" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy S22 5G", year: 2022,
    price: 720000, originalPrice: 820000,
    description: "Compact flagship with Snapdragon 8 Gen 1, excellent cameras, and premium glass-metal design.",
    specifications: {
      display: "6.1\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 1500 nits",
      processor: "Qualcomm Snapdragon 8 Gen 1 (4nm)",
      ram: "8GB LPDDR5",
      storage: "256GB UFS 3.1",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 10MP Front",
      battery: "3700mAh, 25W Wired + 15W Wireless",
      os: "Android 12, One UI 4.1, upgradable to Android 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.2, USB-C",
      weight: "168g",
      dimensions: "146.0 x 70.6 x 7.6 mm"
    },
    images: [img("samsung", "galaxy-s22", 1), img("samsung", "galaxy-s22", 2), img("samsung", "galaxy-s22", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Phantom White", hex: "#f5f5f5" }, { name: "Green", hex: "#2e8b57" }, { name: "Pink Gold", hex: "#e8b4b8" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy Z Fold4", year: 2022,
    price: 1350000, originalPrice: 1550000,
    description: "Galaxy Z Fold4 is a productivity powerhouse with foldable display, Snapdragon 8+ Gen 1, and S Pen support.",
    specifications: {
      display: "7.6\" Foldable Dynamic AMOLED 2X, 120Hz + 6.2\" Cover Display",
      processor: "Qualcomm Snapdragon 8+ Gen 1 (4nm)",
      ram: "12GB LPDDR5",
      storage: "1TB UFS 3.1",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 4MP Under-display + 10MP Cover",
      battery: "4400mAh, 25W Wired + 15W Wireless",
      os: "Android 12L, One UI 4.1.1, upgradable to Android 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.2, USB-C",
      weight: "263g",
      dimensions: "Unfolded: 155.1 x 130.1 x 6.3 mm"
    },
    images: [img("samsung", "galaxy-z-fold4", 1), img("samsung", "galaxy-z-fold4", 2), img("samsung", "galaxy-z-fold4", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Beige", hex: "#f5f5dc" }, { name: "Graygreen", hex: "#708090" }, { name: "Burgundy", hex: "#800020" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy Z Flip4", year: 2022,
    price: 950000, originalPrice: 1100000,
    description: "Galaxy Z Flip4 brings stylish foldable design, Snapdragon 8+ Gen 1, and improved battery life.",
    specifications: {
      display: "6.7\" Foldable Dynamic AMOLED 2X, 120Hz + 1.9\" Cover Display",
      processor: "Qualcomm Snapdragon 8+ Gen 1 (4nm)",
      ram: "8GB LPDDR5",
      storage: "512GB UFS 3.1",
      camera: "12MP Main + 12MP Ultrawide, 10MP Front",
      battery: "3700mAh, 25W Wired + 15W Wireless",
      os: "Android 12L, One UI 4.1.1, upgradable to Android 16",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.2, USB-C",
      weight: "187g",
      dimensions: "Unfolded: 165.2 x 71.9 x 6.9 mm"
    },
    images: [img("samsung", "galaxy-z-flip4", 1), img("samsung", "galaxy-z-flip4", 2), img("samsung", "galaxy-z-flip4", 3)],
    colors: [{ name: "Bora Purple", hex: "#6c3082" }, { name: "Graphite", hex: "#252525" }, { name: "Pink Gold", hex: "#e8b4b8" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },

  // ==================== SAMSUNG GALAXY 2023 ====================
  {
    brand: "Samsung", model: "Galaxy S23 Ultra", year: 2023,
    price: 1400000, originalPrice: 1600000,
    description: "Galaxy S23 Ultra features 200MP camera, Snapdragon 8 Gen 2 for Galaxy, built-in S Pen, and stunning display.",
    specifications: {
      display: "6.8\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 1750 nits",
      processor: "Qualcomm Snapdragon 8 Gen 2 for Galaxy (4nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide + 10MP Telephoto 3x + 10MP Telephoto 10x, 12MP Front",
      battery: "5000mAh, 45W Wired + 15W Wireless + 4.5W Reverse",
      os: "Android 13, One UI 5.1, upgradable to Android 17",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "233g",
      dimensions: "163.4 x 78.1 x 8.9 mm"
    },
    images: [img("samsung", "galaxy-s23-ultra", 1), img("samsung", "galaxy-s23-ultra", 2), img("samsung", "galaxy-s23-ultra", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Cream", hex: "#fffdd0" }, { name: "Green", hex: "#2e8b57" }, { name: "Lavender", hex: "#b57edc" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy S23+", year: 2023,
    price: 1000000, originalPrice: 1150000,
    description: "Galaxy S23+ features Snapdragon 8 Gen 2 for Galaxy, larger display, and improved battery life.",
    specifications: {
      display: "6.6\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 1750 nits",
      processor: "Qualcomm Snapdragon 8 Gen 2 for Galaxy (4nm)",
      ram: "8GB LPDDR5X",
      storage: "512GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "4700mAh, 45W Wired + 15W Wireless",
      os: "Android 13, One UI 5.1, upgradable to Android 17",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "195g",
      dimensions: "157.8 x 76.2 x 7.6 mm"
    },
    images: [img("samsung", "galaxy-s23-plus", 1), img("samsung", "galaxy-s23-plus", 2), img("samsung", "galaxy-s23-plus", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Cream", hex: "#fffdd0" }, { name: "Green", hex: "#2e8b57" }, { name: "Lavender", hex: "#b57edc" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy S23", year: 2023,
    price: 820000, originalPrice: 950000,
    description: "Compact flagship excellence with Snapdragon 8 Gen 2 for Galaxy, improved cameras, and eco-friendly design.",
    specifications: {
      display: "6.1\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 1750 nits",
      processor: "Qualcomm Snapdragon 8 Gen 2 for Galaxy (4nm)",
      ram: "8GB LPDDR5X",
      storage: "256GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "3900mAh, 25W Wired + 15W Wireless",
      os: "Android 13, One UI 5.1, upgradable to Android 17",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "168g",
      dimensions: "146.3 x 70.9 x 7.6 mm"
    },
    images: [img("samsung", "galaxy-s23", 1), img("samsung", "galaxy-s23", 2), img("samsung", "galaxy-s23", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Cream", hex: "#fffdd0" }, { name: "Green", hex: "#2e8b57" }, { name: "Lavender", hex: "#b57edc" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy Z Fold5", year: 2023,
    price: 1550000, originalPrice: 1750000,
    description: "Galaxy Z Fold5 features new flex hinge, slimmer design, Snapdragon 8 Gen 2 for Galaxy, and improved multitasking.",
    specifications: {
      display: "7.6\" Foldable Dynamic AMOLED 2X, 120Hz + 6.2\" Cover Display",
      processor: "Qualcomm Snapdragon 8 Gen 2 for Galaxy (4nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 4MP Under-display + 10MP Cover",
      battery: "4400mAh, 25W Wired + 15W Wireless",
      os: "Android 13, One UI 5.1.1, upgradable to Android 17",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "253g",
      dimensions: "Unfolded: 154.9 x 129.9 x 6.1 mm"
    },
    images: [img("samsung", "galaxy-z-fold5", 1), img("samsung", "galaxy-z-fold5", 2), img("samsung", "galaxy-z-fold5", 3)],
    colors: [{ name: "Phantom Black", hex: "#1a1a1a" }, { name: "Cream", hex: "#fffdd0" }, { name: "Icy Blue", hex: "#a5f2f3" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },
  {
    brand: "Samsung", model: "Galaxy Z Flip5", year: 2023,
    price: 1100000, originalPrice: 1280000,
    description: "Galaxy Z Flip5 introduces a large Flex Window cover display, new hinge design, and powerful Snapdragon chip.",
    specifications: {
      display: "6.7\" Foldable Dynamic AMOLED 2X, 120Hz + 3.4\" Flex Window Cover",
      processor: "Qualcomm Snapdragon 8 Gen 2 for Galaxy (4nm)",
      ram: "8GB LPDDR5X",
      storage: "512GB UFS 4.0",
      camera: "12MP Main + 12MP Ultrawide, 10MP Front",
      battery: "3700mAh, 25W Wired + 15W Wireless",
      os: "Android 13, One UI 5.1.1, upgradable to Android 17",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.3, USB-C",
      weight: "187g",
      dimensions: "Unfolded: 165.1 x 71.9 x 6.9 mm"
    },
    images: [img("samsung", "galaxy-z-flip5", 1), img("samsung", "galaxy-z-flip5", 2), img("samsung", "galaxy-z-flip5", 3)],
    colors: [{ name: "Mint", hex: "#98ff98" }, { name: "Graphite", hex: "#252525" }, { name: "Cream", hex: "#fffdd0" }, { name: "Lavender", hex: "#b57edc" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: false
  },

  // ==================== SAMSUNG GALAXY 2024 ====================
  {
    brand: "Samsung", model: "Galaxy S24 Ultra", year: 2024,
    price: 1700000, originalPrice: 1950000,
    description: "Galaxy S24 Ultra features Galaxy AI, Snapdragon 8 Gen 3, titanium frame, 200MP camera, and built-in S Pen.",
    specifications: {
      display: "6.8\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 2600 nits peak",
      processor: "Qualcomm Snapdragon 8 Gen 3 for Galaxy (4nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide + 10MP Telephoto 3x + 50MP Telephoto 5x, 12MP Front",
      battery: "5000mAh, 45W Wired + 15W Wireless + 4.5W Reverse",
      os: "Android 14, One UI 6.1 with Galaxy AI, upgradable to Android 18",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C",
      weight: "232g",
      dimensions: "162.3 x 79.0 x 8.6 mm"
    },
    images: [img("samsung", "galaxy-s24-ultra", 1), img("samsung", "galaxy-s24-ultra", 2), img("samsung", "galaxy-s24-ultra", 3)],
    colors: [{ name: "Titanium Black", hex: "#1a1a1a" }, { name: "Titanium Gray", hex: "#696969" }, { name: "Titanium Violet", hex: "#8a2be2" }, { name: "Titanium Yellow", hex: "#daa520" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S24+", year: 2024,
    price: 1200000, originalPrice: 1380000,
    description: "Galaxy S24+ brings Galaxy AI features, Snapdragon 8 Gen 3, larger display, and premium titanium design.",
    specifications: {
      display: "6.7\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 2600 nits peak",
      processor: "Qualcomm Snapdragon 8 Gen 3 for Galaxy (4nm)",
      ram: "12GB LPDDR5X",
      storage: "512GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "4900mAh, 45W Wired + 15W Wireless",
      os: "Android 14, One UI 6.1 with Galaxy AI, upgradable to Android 18",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C",
      weight: "196g",
      dimensions: "158.5 x 75.9 x 7.7 mm"
    },
    images: [img("samsung", "galaxy-s24-plus", 1), img("samsung", "galaxy-s24-plus", 2), img("samsung", "galaxy-s24-plus", 3)],
    colors: [{ name: "Onyx Black", hex: "#0f0f0f" }, { name: "Marble Gray", hex: "#808080" }, { name: "Cobalt Violet", hex: "#6a5acd" }, { name: "Amber Yellow", hex: "#ffbf00" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S24", year: 2024,
    price: 980000, originalPrice: 1120000,
    description: "Galaxy S24 introduces Galaxy AI in a compact form with Snapdragon 8 Gen 3 and premium design.",
    specifications: {
      display: "6.2\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 2600 nits peak",
      processor: "Qualcomm Snapdragon 8 Gen 3 for Galaxy (4nm)",
      ram: "8GB LPDDR5X",
      storage: "256GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "4000mAh, 25W Wired + 15W Wireless",
      os: "Android 14, One UI 6.1 with Galaxy AI, upgradable to Android 18",
      connectivity: "5G, 4G LTE, Wi-Fi 6E, Bluetooth 5.4, USB-C",
      weight: "167g",
      dimensions: "147.0 x 70.6 x 7.6 mm"
    },
    images: [img("samsung", "galaxy-s24", 1), img("samsung", "galaxy-s24", 2), img("samsung", "galaxy-s24", 3)],
    colors: [{ name: "Onyx Black", hex: "#0f0f0f" }, { name: "Marble Gray", hex: "#808080" }, { name: "Cobalt Violet", hex: "#6a5acd" }, { name: "Amber Yellow", hex: "#ffbf00" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy Z Fold6", year: 2024,
    price: 1850000, originalPrice: 2100000,
    description: "Galaxy Z Fold6 features slimmer design, Snapdragon 8 Gen 3, Galaxy AI, and improved productivity features.",
    specifications: {
      display: "7.6\" Foldable Dynamic AMOLED 2X, 120Hz + 6.3\" Cover Display",
      processor: "Qualcomm Snapdragon 8 Gen 3 for Galaxy (4nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 4MP Under-display + 10MP Cover",
      battery: "4400mAh, 25W Wired + 15W Wireless",
      os: "Android 14, One UI 6.1.1 with Galaxy AI, upgradable to Android 18",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C",
      weight: "239g",
      dimensions: "Unfolded: 153.5 x 132.6 x 5.6 mm"
    },
    images: [img("samsung", "galaxy-z-fold6", 1), img("samsung", "galaxy-z-fold6", 2), img("samsung", "galaxy-z-fold6", 3)],
    colors: [{ name: "Silver Shadow", hex: "#c0c0c0" }, { name: "Navy", hex: "#000080" }, { name: "Pink", hex: "#ffc0cb" }, { name: "White", hex: "#ffffff" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy Z Flip6", year: 2024,
    price: 1300000, originalPrice: 1500000,
    description: "Galaxy Z Flip6 features larger Flex Window, Snapdragon 8 Gen 3, Galaxy AI, and improved camera system.",
    specifications: {
      display: "6.7\" Foldable Dynamic AMOLED 2X, 120Hz + 3.6\" Flex Window Cover",
      processor: "Qualcomm Snapdragon 8 Gen 3 for Galaxy (4nm)",
      ram: "12GB LPDDR5X",
      storage: "512GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide, 10MP Front",
      battery: "4000mAh, 25W Wired + 15W Wireless",
      os: "Android 14, One UI 6.1.1 with Galaxy AI, upgradable to Android 18",
      connectivity: "5G, 4G LTE, Wi-Fi 7, Bluetooth 5.4, USB-C",
      weight: "185g",
      dimensions: "Unfolded: 165.1 x 71.9 x 6.9 mm"
    },
    images: [img("samsung", "galaxy-z-flip6", 1), img("samsung", "galaxy-z-flip6", 2), img("samsung", "galaxy-z-flip6", 3)],
    colors: [{ name: "Mint", hex: "#98ff98" }, { name: "Graphite", hex: "#252525" }, { name: "Yellow", hex: "#ffd700" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },

  // ==================== SAMSUNG GALAXY 2025 ====================
  {
    brand: "Samsung", model: "Galaxy S25 Ultra", year: 2025,
    price: 2000000, originalPrice: 2250000,
    description: "Galaxy S25 Ultra features Snapdragon 8 Elite, Galaxy AI 2.0, advanced 200MP camera, and premium titanium design.",
    specifications: {
      display: "6.9\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 3000 nits peak",
      processor: "Qualcomm Snapdragon 8 Elite (4nm)",
      ram: "12GB LPDDR5X",
      storage: "1TB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide + 10MP Telephoto 3x + 50MP Telephoto 10x, 12MP Front",
      battery: "5200mAh, 65W Wired + 25W Wireless + 10W Reverse",
      os: "Android 15, One UI 7 with Galaxy AI 2.0, upgradable to Android 19",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "228g",
      dimensions: "162.0 x 78.8 x 8.4 mm"
    },
    images: [img("samsung", "galaxy-s25-ultra", 1), img("samsung", "galaxy-s25-ultra", 2), img("samsung", "galaxy-s25-ultra", 3)],
    colors: [{ name: "Titanium Black", hex: "#1a1a1a" }, { name: "Titanium Silver", hex: "#c0c0c0" }, { name: "Titanium Blue", hex: "#4682b4" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S25+", year: 2025,
    price: 1400000, originalPrice: 1600000,
    description: "Galaxy S25+ brings Snapdragon 8 Elite power, Galaxy AI 2.0, and larger display with improved battery.",
    specifications: {
      display: "6.7\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 3000 nits peak",
      processor: "Qualcomm Snapdragon 8 Elite (4nm)",
      ram: "12GB LPDDR5X",
      storage: "512GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "5000mAh, 65W Wired + 25W Wireless",
      os: "Android 15, One UI 7 with Galaxy AI 2.0, upgradable to Android 19",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "193g",
      dimensions: "158.2 x 75.8 x 7.5 mm"
    },
    images: [img("samsung", "galaxy-s25-plus", 1), img("samsung", "galaxy-s25-plus", 2), img("samsung", "galaxy-s25-plus", 3)],
    colors: [{ name: "Midnight Black", hex: "#0f0f0f" }, { name: "Silver", hex: "#c0c0c0" }, { name: "Navy Blue", hex: "#000080" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S25", year: 2025,
    price: 1100000, originalPrice: 1280000,
    description: "Compact flagship with Snapdragon 8 Elite, Galaxy AI 2.0, and premium flat display design.",
    specifications: {
      display: "6.2\" Dynamic AMOLED 2X, 120Hz, Vision Booster, 3000 nits peak",
      processor: "Qualcomm Snapdragon 8 Elite (4nm)",
      ram: "12GB LPDDR5X",
      storage: "256GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "4200mAh, 45W Wired + 25W Wireless",
      os: "Android 15, One UI 7 with Galaxy AI 2.0, upgradable to Android 19",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "165g",
      dimensions: "146.8 x 70.5 x 7.5 mm"
    },
    images: [img("samsung", "galaxy-s25", 1), img("samsung", "galaxy-s25", 2), img("samsung", "galaxy-s25", 3)],
    colors: [{ name: "Midnight Black", hex: "#0f0f0f" }, { name: "Silver", hex: "#c0c0c0" }, { name: "Navy Blue", hex: "#000080" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S25 Edge", year: 2025,
    price: 1550000, originalPrice: 1780000,
    description: "Galaxy S25 Edge features curved edge display, Snapdragon 8 Elite, and unique dual camera system.",
    specifications: {
      display: "6.7\" Curved Dynamic AMOLED 2X, 120Hz, Vision Booster, 3000 nits",
      processor: "Qualcomm Snapdragon 8 Elite (4nm)",
      ram: "12GB LPDDR5X",
      storage: "512GB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide, 12MP Front",
      battery: "4800mAh, 65W Wired + 25W Wireless",
      os: "Android 15, One UI 7 with Galaxy AI 2.0, upgradable to Android 19",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "188g",
      dimensions: "157.0 x 75.0 x 7.3 mm"
    },
    images: [img("samsung", "galaxy-s25-edge", 1), img("samsung", "galaxy-s25-edge", 2), img("samsung", "galaxy-s25-edge", 3)],
    colors: [{ name: "Titanium Black", hex: "#1a1a1a" }, { name: "Titanium Gold", hex: "#d4af37" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy Z Fold7", year: 2025,
    price: 2100000, originalPrice: 2400000,
    description: "Galaxy Z Fold7 features larger 8.0-inch display, Snapdragon 8 Elite, and ultra-thin design with Galaxy AI 2.0.",
    specifications: {
      display: "8.0\" Foldable Dynamic AMOLED 2X, 120Hz + 6.4\" Cover Display",
      processor: "Qualcomm Snapdragon 8 Elite (4nm)",
      ram: "16GB LPDDR5X",
      storage: "1TB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 4MP Under-display + 10MP Cover",
      battery: "4600mAh, 45W Wired + 25W Wireless",
      os: "Android 15, One UI 7 with Galaxy AI 2.0, upgradable to Android 19",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.4, USB-C 3.2",
      weight: "232g",
      dimensions: "Unfolded: 154.0 x 135.0 x 5.2 mm"
    },
    images: [img("samsung", "galaxy-z-fold7", 1), img("samsung", "galaxy-z-fold7", 2), img("samsung", "galaxy-z-fold7", 3)],
    colors: [{ name: "Silver", hex: "#c0c0c0" }, { name: "Black", hex: "#0a0a0a" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },

  // ==================== SAMSUNG GALAXY 2026 ====================
  {
    brand: "Samsung", model: "Galaxy S26 Ultra", year: 2026,
    price: 2350000, originalPrice: 2650000,
    description: "Galaxy S26 Ultra features Snapdragon 8 Elite Gen 2, Dynamic AMOLED 3X, Galaxy AI 3.0, and revolutionary 200MP quad camera.",
    specifications: {
      display: "6.9\" Dynamic AMOLED 3X, 144Hz, Vision Booster Pro, 3500 nits peak",
      processor: "Qualcomm Snapdragon 8 Elite Gen 2 (3nm)",
      ram: "16GB LPDDR6",
      storage: "2TB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide + 10MP Telephoto 3x + 50MP Telephoto 10x, 12MP Front",
      battery: "5500mAh, 80W Wired + 35W Wireless + 15W Reverse",
      os: "Android 16, One UI 8 with Galaxy AI 3.0, upgradable to Android 20",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "225g",
      dimensions: "161.8 x 78.5 x 8.2 mm"
    },
    images: [img("samsung", "galaxy-s26-ultra", 1), img("samsung", "galaxy-s26-ultra", 2), img("samsung", "galaxy-s26-ultra", 3)],
    colors: [{ name: "Titanium Black", hex: "#1a1a1a" }, { name: "Titanium White", hex: "#f5f5f5" }, { name: "Titanium Navy", hex: "#000080" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S26+", year: 2026,
    price: 1650000, originalPrice: 1880000,
    description: "Galaxy S26+ brings Snapdragon 8 Elite Gen 2, Dynamic AMOLED 3X, and Galaxy AI 3.0 to the plus lineup.",
    specifications: {
      display: "6.7\" Dynamic AMOLED 3X, 144Hz, Vision Booster Pro, 3500 nits peak",
      processor: "Qualcomm Snapdragon 8 Elite Gen 2 (3nm)",
      ram: "12GB LPDDR6",
      storage: "1TB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "5200mAh, 80W Wired + 35W Wireless",
      os: "Android 16, One UI 8 with Galaxy AI 3.0, upgradable to Android 20",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "190g",
      dimensions: "158.0 x 75.6 x 7.3 mm"
    },
    images: [img("samsung", "galaxy-s26-plus", 1), img("samsung", "galaxy-s26-plus", 2), img("samsung", "galaxy-s26-plus", 3)],
    colors: [{ name: "Cosmic Black", hex: "#0f0f0f" }, { name: "Platinum Silver", hex: "#e5e4e2" }, { name: "Ocean Blue", hex: "#006994" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: false, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy S26", year: 2026,
    price: 1300000, originalPrice: 1480000,
    description: "Compact flagship perfection with Snapdragon 8 Elite Gen 2, Dynamic AMOLED 3X, and Galaxy AI 3.0.",
    specifications: {
      display: "6.2\" Dynamic AMOLED 3X, 144Hz, Vision Booster Pro, 3500 nits peak",
      processor: "Qualcomm Snapdragon 8 Elite Gen 2 (3nm)",
      ram: "12GB LPDDR6",
      storage: "512GB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 12MP Front",
      battery: "4400mAh, 65W Wired + 35W Wireless",
      os: "Android 16, One UI 8 with Galaxy AI 3.0, upgradable to Android 20",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "162g",
      dimensions: "146.5 x 70.3 x 7.3 mm"
    },
    images: [img("samsung", "galaxy-s26", 1), img("samsung", "galaxy-s26", 2), img("samsung", "galaxy-s26", 3)],
    colors: [{ name: "Cosmic Black", hex: "#0f0f0f" }, { name: "Platinum Silver", hex: "#e5e4e2" }, { name: "Ocean Blue", hex: "#006994" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy Z Fold8", year: 2026,
    price: 2450000, originalPrice: 2800000,
    description: "Galaxy Z Fold8 features massive 8.2-inch foldable display, Snapdragon 8 Elite Gen 2, and Galaxy AI 3.0.",
    specifications: {
      display: "8.2\" Foldable Dynamic AMOLED 3X, 144Hz + 6.5\" Cover Display",
      processor: "Qualcomm Snapdragon 8 Elite Gen 2 (3nm)",
      ram: "16GB LPDDR6",
      storage: "2TB UFS 4.0",
      camera: "200MP Main + 12MP Ultrawide + 10MP Telephoto 3x, 4MP Under-display + 12MP Cover",
      battery: "4800mAh, 65W Wired + 35W Wireless",
      os: "Android 16, One UI 8 with Galaxy AI 3.0, upgradable to Android 20",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "228g",
      dimensions: "Unfolded: 154.5 x 138.0 x 5.0 mm"
    },
    images: [img("samsung", "galaxy-z-fold8", 1), img("samsung", "galaxy-z-fold8", 2), img("samsung", "galaxy-z-fold8", 3)],
    colors: [{ name: "Platinum", hex: "#e5e4e2" }, { name: "Obsidian", hex: "#0a0a0a" }, { name: "Sapphire", hex: "#0f52ba" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  },
  {
    brand: "Samsung", model: "Galaxy Z Flip8", year: 2026,
    price: 1600000, originalPrice: 1850000,
    description: "Galaxy Z Flip8 features improved Flex Window, Snapdragon 8 Elite Gen 2, 50MP dual cameras, and Galaxy AI 3.0.",
    specifications: {
      display: "6.9\" Foldable Dynamic AMOLED 3X, 144Hz + 3.8\" Flex Window Cover",
      processor: "Qualcomm Snapdragon 8 Elite Gen 2 (3nm)",
      ram: "12GB LPDDR6",
      storage: "1TB UFS 4.0",
      camera: "50MP Main + 12MP Ultrawide, 12MP Front",
      battery: "4200mAh, 45W Wired + 25W Wireless",
      os: "Android 16, One UI 8 with Galaxy AI 3.0, upgradable to Android 20",
      connectivity: "5G Advanced, Wi-Fi 7, Bluetooth 5.5, USB-C 4.0",
      weight: "182g",
      dimensions: "Unfolded: 165.0 x 71.8 x 6.5 mm"
    },
    images: [img("samsung", "galaxy-z-flip8", 1), img("samsung", "galaxy-z-flip8", 2), img("samsung", "galaxy-z-flip8", 3)],
    colors: [{ name: "Jade", hex: "#00a86b" }, { name: "Graphite", hex: "#252525" }, { name: "Peach", hex: "#ffdab9" }, { name: "Blue", hex: "#4169e1" }],
    stock: randomStock(), rating: randomRating(), numReviews: randomReviews(),
    isFeatured: true, isNewArrival: true
  }
];

// Function to seed products
const seedProducts = async () => {
  try {
    console.log("Clearing existing products...");
    await Product.deleteMany({});
    
    console.log(`Seeding ${products.length} products...`);
    
    // Add slugs
    const productsWithSlugs = products.map(p => ({
      ...p,
      slug: makeSlug(p.brand, p.model, p.year)
    }));
    
    await Product.insertMany(productsWithSlugs);
    
    console.log(`\n✅ Successfully seeded ${products.length} products!`);
    console.log(`\n📊 Brand breakdown:`);
    const brands = ["Infinix", "Apple", "Samsung"];
    for (const brand of brands) {
      const count = products.filter(p => p.brand === brand).length;
      console.log(`   ${brand}: ${count} products`);
    }
    
    console.log(`\n📅 Year breakdown:`);
    for (let year = 2022; year <= 2026; year++) {
      const count = products.filter(p => p.year === year).length;
      console.log(`   ${year}: ${count} products`);
    }
    
    process.exit(0);
  } catch (error) {
    console.error("❌ Seeding error:", error.message);
    process.exit(1);
  }
};

seedProducts();
