const { validationResult } = require("express-validator");
const Order = require("../models/Order");
const Product = require("../models/Product");
const Cart = require("../models/Cart");
const { sendEmail, notifyAdmin } = require("../utils/sendEmail");
const templates = require("../utils/emailTemplates");

// @desc    Create new order
// @route   POST /api/orders
// @access  Public
const createOrder = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    const { items, shippingAddress, paymentMethod, shippingFee = 0, tax = 0, notes, cartId, email } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ success: false, message: "No items in order" });
    }

    const customerEmail = email || shippingAddress.email;
    if (!customerEmail) {
      return res.status(400).json({ success: false, message: "Email is required" });
    }

    // Validate products and calculate totals
    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await Product.findById(item.product);
      if (!product) {
        return res.status(404).json({ success: false, message: `Product not found: ${item.product}` });
      }
      if (product.stock < item.quantity) {
        return res.status(400).json({ success: false, message: `Not enough stock for ${product.model}` });
      }
      const itemTotal = product.price * item.quantity;
      subtotal += itemTotal;
      orderItems.push({
        product: product._id,
        name: `${product.brand} ${product.model}`,
        brand: product.brand,
        model: product.model,
        price: product.price,
        quantity: item.quantity,
        image: product.images[0]
      });
    }

    const total = subtotal + shippingFee + tax;

    const order = await Order.create({
      customerEmail,
      customerName: shippingAddress.fullName,
      customerPhone: shippingAddress.phone,
      items: orderItems,
      shippingAddress: {
        ...shippingAddress,
        email: customerEmail
      },
      paymentMethod,
      subtotal,
      shippingFee,
      tax,
      total,
      notes,
      statusHistory: [{ status: "processing" }]
    });

    // Clear cart if cartId provided
    if (cartId) {
      await Cart.findOneAndDelete({ cartId });
    }

    // Deduct stock
    for (const item of orderItems) {
      await Product.findByIdAndUpdate(item.product, {
        $inc: { stock: -item.quantity }
      });
    }

    // Send order confirmation email
    try {
      const orderHtml = templates.orderConfirmationEmail(order);
      await sendEmail({
        to: customerEmail,
        subject: `Order Confirmation - ${order.orderNumber}`,
        html: orderHtml,
        type: "order-confirmation",
        orderId: order._id
      });

      // Notify admin
      await notifyAdmin(
        `New Order ${order.orderNumber}`,
        `<p><strong>Order:</strong> ${order.orderNumber}</p><p><strong>Customer:</strong> ${shippingAddress.fullName} (${customerEmail})</p><p><strong>Phone:</strong> ${shippingAddress.phone}</p><p><strong>Total:</strong> ₦${order.total.toLocaleString()}</p><p><strong>Items:</strong> ${order.items.length}</p><p><strong>Payment:</strong> ${order.paymentMethod}</p><p><strong>City:</strong> ${shippingAddress.city}, ${shippingAddress.state}</p>`
      );
    } catch (emailError) {
      console.error("Email send failed (non-critical):", emailError.message);
    }

    res.status(201).json({
      success: true,
      message: "Order created successfully",
      order: {
        id: order._id,
        orderNumber: order.orderNumber,
        total: order.total,
        paymentStatus: order.paymentStatus,
        orderStatus: order.orderStatus,
        customerEmail
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get orders by email
// @route   GET /api/orders/lookup?email=xxx
// @access  Public
const getOrdersByEmail = async (req, res, next) => {
  try {
    const { email } = req.query;
    
    if (!email) {
      return res.status(400).json({ success: false, message: "Email is required" });
    }
    
    const orders = await Order.find({ customerEmail: email.toLowerCase() })
      .sort({ createdAt: -1 })
      .select("-paystackData -statusHistory");
    
    res.json({ success: true, count: orders.length, orders });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single order by orderNumber + email
// @route   GET /api/orders/lookup-one?orderNumber=xxx&email=xxx
// @access  Public
const getOrderByLookup = async (req, res, next) => {
  try {
    const { orderNumber, email } = req.query;
    
    if (!orderNumber || !email) {
      return res.status(400).json({ success: false, message: "Order number and email are required" });
    }
    
    const order = await Order.findOne({ 
      orderNumber: orderNumber.toUpperCase(),
      customerEmail: email.toLowerCase()
    });
    
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }
    
    res.json({ success: true, order });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single order by ID (admin only in future, now public)
// @route   GET /api/orders/:id
// @access  Public
const getOrderById = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }
    res.json({ success: true, order });
  } catch (error) {
    next(error);
  }
};

// @desc    Cancel order
// @route   PUT /api/orders/:id/cancel
// @access  Public (with email verification)
const cancelOrder = async (req, res, next) => {
  try {
    const { email } = req.body;
    const order = await Order.findById(req.params.id);
    
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }
    
    if (email && order.customerEmail.toLowerCase() !== email.toLowerCase()) {
      return res.status(403).json({ success: false, message: "Email does not match this order" });
    }
    
    if (order.orderStatus !== "processing") {
      return res.status(400).json({ success: false, message: "Order cannot be cancelled at this stage" });
    }
    
    order.orderStatus = "cancelled";
    order.statusHistory.push({ status: "cancelled", note: "Cancelled by customer" });
    await order.save();
    
    res.json({ success: true, message: "Order cancelled successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createOrder,
  getOrdersByEmail,
  getOrderByLookup,
  getOrderById,
  cancelOrder
};
