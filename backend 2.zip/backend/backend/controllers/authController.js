const crypto = require("crypto");
const { validationResult } = require("express-validator");
const User = require("../models/User");
const { generateToken } = require("../utils/generateToken");
const { sendEmail, notifyAdmin } = require("../utils/sendEmail");
const templates = require("../utils/emailTemplates");

// @desc    Register user
// @route   POST /api/auth/signup
// @access  Public
const signup = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    const { fullName, email, password, phone } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ success: false, message: "Email already registered" });
    }

    const user = await User.create({
      fullName,
      email,
      password,
      phone
    });

    // Generate verification token
    const verifyToken = user.getVerificationToken();
    await user.save();

    // Generate JWT
    const token = generateToken(res, user._id, user.role);

    // Send welcome email
    const verifyLink = `${process.env.FRONTEND_URL}/verify-email.html?token=${verifyToken}`;
    const welcomeHtml = templates.welcomeEmail(user.fullName, verifyLink);
    await sendEmail({
      to: user.email,
      subject: "Welcome to MobileShop! Verify Your Email",
      html: welcomeHtml,
      type: "welcome",
      userId: user._id
    });

    // Notify admin
    await notifyAdmin(
      "New User Registered",
      `<p><strong>Name:</strong> ${user.fullName}</p><p><strong>Email:</strong> ${user.email}</p><p><strong>Phone:</strong> ${user.phone}</p><p><strong>Joined:</strong> ${new Date().toLocaleString()}</p>`
    );

    res.status(201).json({
      success: true,
      message: "Registration successful. Please verify your email.",
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
const login = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    const { email, password } = req.body;

    const user = await User.findOne({ email }).select("+password");
    if (!user) {
      return res.status(401).json({ success: false, message: "Invalid email or password" });
    }

    if (user.isBanned) {
      return res.status(401).json({ success: false, message: "Account has been banned" });
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: "Invalid email or password" });
    }

    // Update login info
    const ip = req.ip || req.connection.remoteAddress || "Unknown";
    const userAgent = req.headers["user-agent"] || "Unknown";
    
    user.lastLogin = Date.now();
    user.loginHistory.unshift({ ip, userAgent });
    if (user.loginHistory.length > 10) user.loginHistory = user.loginHistory.slice(0, 10);
    await user.save();

    // Generate JWT
    const token = generateToken(res, user._id, user.role);

    // Send login alert email
    const loginHtml = templates.loginAlertEmail(
      user.fullName,
      ip,
      userAgent.substring(0, 100),
      new Date().toLocaleString()
    );
    await sendEmail({
      to: user.email,
      subject: "New Login to Your MobileShop Account",
      html: loginHtml,
      type: "login-alert",
      userId: user._id
    });

    // Notify admin
    await notifyAdmin(
      "User Login",
      `<p><strong>User:</strong> ${user.fullName} (${user.email})</p><p><strong>IP:</strong> ${ip}</p><p><strong>Time:</strong> ${new Date().toLocaleString()}</p>`
    );

    res.json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isVerified: user.isVerified,
        address: user.address
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Private
const logout = async (req, res) => {
  res.cookie("token", "", {
    httpOnly: true,
    expires: new Date(0)
  });
  res.cookie("adminToken", "", {
    httpOnly: true,
    expires: new Date(0)
  });
  res.json({ success: true, message: "Logged out successfully" });
};

// @desc    Get current user profile
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    res.json({
      success: true,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isVerified: user.isVerified,
        address: user.address,
        wishlist: user.wishlist,
        lastLogin: user.lastLogin,
        createdAt: user.createdAt
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
const updateProfile = async (req, res, next) => {
  try {
    const { fullName, phone, address } = req.body;
    
    const user = await User.findById(req.user._id);
    
    if (fullName) user.fullName = fullName;
    if (phone) user.phone = phone;
    if (address) user.address = { ...user.address, ...address };
    
    await user.save();
    
    res.json({
      success: true,
      message: "Profile updated successfully",
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        address: user.address
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Change password
// @route   PUT /api/auth/password
// @access  Private
const changePassword = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    const { currentPassword, newPassword } = req.body;
    
    const user = await User.findById(req.user._id).select("+password");
    
    const isMatch = await user.matchPassword(currentPassword);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: "Current password is incorrect" });
    }
    
    user.password = newPassword;
    await user.save();
    
    // Send confirmation email
    const confirmHtml = templates.passwordResetConfirmEmail(user.fullName);
    await sendEmail({
      to: user.email,
      subject: "Your Password Has Been Changed",
      html: confirmHtml,
      type: "password-reset-confirm",
      userId: user._id
    });
    
    res.json({ success: true, message: "Password changed successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Forgot password
// @route   POST /api/auth/forgot-password
// @access  Public
const forgotPassword = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    const { email } = req.body;
    const user = await User.findOne({ email });

    // Always return same message for security
    const genericMessage = "If an account exists with that email, a password reset link has been sent.";

    if (!user) {
      return res.json({ success: true, message: genericMessage });
    }

    // Generate reset token
    const resetToken = user.getResetPasswordToken();
    await user.save();

    // Send reset email
    const resetLink = `${process.env.FRONTEND_URL}/reset-password.html?token=${resetToken}`;
    const resetHtml = templates.passwordResetEmail(user.fullName, resetLink);
    await sendEmail({
      to: user.email,
      subject: "Reset Your MobileShop Password",
      html: resetHtml,
      type: "password-reset",
      userId: user._id
    });

    // Notify admin
    await notifyAdmin(
      "Password Reset Requested",
      `<p><strong>User:</strong> ${user.fullName} (${user.email})</p><p><strong>Time:</strong> ${new Date().toLocaleString()}</p>`
    );

    res.json({ success: true, message: genericMessage });
  } catch (error) {
    next(error);
  }
};

// @desc    Reset password
// @route   PUT /api/auth/reset-password/:token
// @access  Public
const resetPassword = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    const { token } = req.params;
    const { password } = req.body;

    // Hash the token from the URL
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpire: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({ success: false, message: "Invalid or expired reset token" });
    }

    // Update password
    user.password = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();

    // Send confirmation email
    const confirmHtml = templates.passwordResetConfirmEmail(user.fullName);
    await sendEmail({
      to: user.email,
      subject: "Password Reset Successful",
      html: confirmHtml,
      type: "password-reset-confirm",
      userId: user._id
    });

    // Notify admin
    await notifyAdmin(
      "Password Reset Completed",
      `<p><strong>User:</strong> ${user.fullName} (${user.email})</p><p><strong>Time:</strong> ${new Date().toLocaleString()}</p>`
    );

    res.json({ success: true, message: "Password reset successfully. You can now login." });
  } catch (error) {
    next(error);
  }
};

// @desc    Verify email
// @route   GET /api/auth/verify-email/:token
// @access  Public
const verifyEmail = async (req, res, next) => {
  try {
    const { token } = req.params;
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
      verificationToken: hashedToken,
      verificationExpire: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({ success: false, message: "Invalid or expired verification token" });
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationExpire = undefined;
    await user.save();

    res.json({ success: true, message: "Email verified successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  signup,
  login,
  logout,
  getMe,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
  verifyEmail
};
