const { validationResult } = require("express-validator");
const Product = require("../models/Product");
const Order = require("../models/Order");
const EmailLog = require("../models/EmailLog");
const { sendEmail } = require("../utils/sendEmail");
const templates = require("../utils/emailTemplates");

// @desc    Get dashboard stats
// @route   GET /api/admin/stats
// @access  Public (no auth)
const getDashboardStats = async (req, res, next) => {
  try {
    const totalOrders = await Order.countDocuments();
    const pendingOrders = await Order.countDocuments({ orderStatus: "processing" });
    const paidOrders = await Order.find({ paymentStatus: "paid" });
    
    const totalRevenue = paidOrders.reduce((sum, order) => sum + order.total, 0);
    
    const lowStockProducts = await Product.countDocuments({ stock: { $lt: 10 }, isActive: true });
    const totalProducts = await Product.countDocuments({ isActive: true });
    
    // Revenue for last 30 days
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const recentOrders = await Order.find({
      paymentStatus: "paid",
      createdAt: { $gte: thirtyDaysAgo }
    });
    
    const revenueByDay = {};
    recentOrders.forEach(order => {
      const day = order.createdAt.toISOString().split("T")[0];
      revenueByDay[day] = (revenueByDay[day] || 0) + order.total;
    });
    
    // Orders by status
    const ordersByStatus = {
      processing: await Order.countDocuments({ orderStatus: "processing" }),
      shipped: await Order.countDocuments({ orderStatus: "shipped" }),
      delivered: await Order.countDocuments({ orderStatus: "delivered" }),
      cancelled: await Order.countDocuments({ orderStatus: "cancelled" })
    };
    
    // Top selling products
    const topProducts = await Order.aggregate([
      { $match: { paymentStatus: "paid" } },
      { $unwind: "$items" },
      { $group: {
        _id: "$items.product",
        name: { $first: "$items.name" },
        brand: { $first: "$items.brand" },
        totalSold: { $sum: "$items.quantity" },
        revenue: { $sum: { $multiply: ["$items.price", "$items.quantity"] } }
      }},
      { $sort: { totalSold: -1 } },
      { $limit: 5 }
    ]);
    
    // Recent orders
    const recentOrdersList = await Order.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .select("orderNumber total orderStatus paymentStatus createdAt customerName customerEmail customerPhone");
    
    // Low stock alerts
    const lowStock = await Product.find({ stock: { $lt: 10 }, isActive: true })
      .sort({ stock: 1 })
      .limit(10)
      .select("brand model year stock slug");
    
    res.json({
      success: true,
      stats: {
        totalOrders,
        totalRevenue,
        pendingOrders,
        lowStockProducts,
        totalProducts,
        revenueByDay,
        ordersByStatus,
        topProducts,
        recentOrders: recentOrdersList,
        lowStock
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all orders
// @route   GET /api/admin/orders
// @access  Public (no auth)
const getAllOrders = async (req, res, next) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    
    let query = {};
    
    if (status && status !== "all") {
      query.orderStatus = status;
    }
    
    if (search) {
      query.$or = [
        { customerEmail: { $regex: search, $options: "i" } },
        { customerName: { $regex: search, $options: "i" } },
        { orderNumber: { $regex: search, $options: "i" } }
      ];
    }
    
    const skip = (Number(page) - 1) * Number(limit);
    const orders = await Order.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit))
      .select("-paystackData");
    
    const total = await Order.countDocuments(query);
    
    res.json({
      success: true,
      count: orders.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      orders
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update order status
// @route   PUT /api/admin/orders/:id/status
// @access  Public (no auth)
const updateOrderStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    
    if (!["processing", "shipped", "delivered", "cancelled"].includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid status" });
    }
    
    const order = await Order.findById(req.params.id);
    
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }
    
    const oldStatus = order.orderStatus;
    order.orderStatus = status;
    order.statusHistory.push({ status, note: `Changed from ${oldStatus} by admin` });
    await order.save();
    
    // Send email notification to customer on status change
    if (order.customerEmail && ["shipped", "delivered", "cancelled"].includes(status)) {
      try {
        const statusHtml = templates.shippingUpdateEmail(order, status);
        await sendEmail({
          to: order.customerEmail,
          subject: `Order ${order.orderNumber} - ${status.charAt(0).toUpperCase() + status.slice(1)}`,
          html: statusHtml,
          type: "shipping-update",
          orderId: order._id
        });
      } catch (emailError) {
        console.error("Status update email failed:", emailError.message);
      }
    }
    
    res.json({
      success: true,
      message: `Order status updated to ${status}`,
      order: {
        id: order._id,
        orderNumber: order.orderNumber,
        orderStatus: order.orderStatus
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create product
// @route   POST /api/admin/products
// @access  Public (no auth)
const createProduct = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }
    
    const product = await Product.create(req.body);
    
    res.status(201).json({
      success: true,
      message: "Product created successfully",
      product
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update product
// @route   PUT /api/admin/products/:id
// @access  Public (no auth)
const updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.json({
      success: true,
      message: "Product updated successfully",
      product: updatedProduct
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete product (soft delete)
// @route   DELETE /api/admin/products/:id
// @access  Public (no auth)
const deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    
    product.isActive = false;
    await product.save();
    
    res.json({ success: true, message: "Product deactivated successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all products (admin)
// @route   GET /api/admin/products
// @access  Public (no auth)
const getAllProductsAdmin = async (req, res, next) => {
  try {
    const { brand, year, search, page = 1, limit = 20 } = req.query;
    
    let query = {};
    
    if (brand) query.brand = brand;
    if (year) query.year = Number(year);
    
    if (search) {
      query.$or = [
        { model: { $regex: search, $options: "i" } },
        { brand: { $regex: search, $options: "i" } }
      ];
    }
    
    const skip = (Number(page) - 1) * Number(limit);
    const products = await Product.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit))
      .select("-reviews -__v");
    
    const total = await Product.countDocuments(query);
    
    res.json({
      success: true,
      count: products.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      products
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get email logs
// @route   GET /api/admin/emails
// @access  Public (no auth)
const getEmailLogs = async (req, res, next) => {
  try {
    const { type, page = 1, limit = 20 } = req.query;
    
    let query = {};
    if (type && type !== "all") query.type = type;
    
    const skip = (Number(page) - 1) * Number(limit);
    const emails = await EmailLog.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));
    
    const total = await EmailLog.countDocuments(query);
    
    res.json({
      success: true,
      count: emails.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      emails
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Export orders to CSV
// @route   GET /api/admin/export/orders
// @access  Public (no auth)
const exportOrdersCSV = async (req, res, next) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    
    let csv = "Order Number,Customer Name,Email,Phone,Items,Subtotal,Shipping,Tax,Total,Status,Payment,Date\n";
    
    orders.forEach(order => {
      const items = order.items.map(i => `${i.name} x${i.quantity}`).join("; ");
      csv += `"${order.orderNumber}","${order.customerName || 'N/A'}","${order.customerEmail || 'N/A'}","${order.customerPhone || 'N/A'}","${items}",${order.subtotal},${order.shippingFee},${order.tax},${order.total},"${order.orderStatus}","${order.paymentStatus}","${order.createdAt.toISOString()}"\n`;
    });
    
    res.header("Content-Type", "text/csv");
    res.attachment(`orders-export-${Date.now()}.csv`);
    res.send(csv);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getDashboardStats,
  getAllOrders,
  updateOrderStatus,
  createProduct,
  updateProduct,
  deleteProduct,
  getAllProductsAdmin,
  getEmailLogs,
  exportOrdersCSV
};
