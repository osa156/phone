const Cart = require("../models/Cart");
const Product = require("../models/Product");

// @desc    Get cart by cartId
// @route   GET /api/cart?cartId=xxx
// @access  Public
const getCart = async (req, res, next) => {
  try {
    const { cartId } = req.query;
    
    if (!cartId) {
      return res.json({ success: true, cart: { items: [] } });
    }
    
    const cart = await Cart.findOne({ cartId }).populate("items.product", "brand model price images stock slug");
    
    if (!cart) {
      return res.json({ success: true, cart: { items: [] } });
    }
    
    // Filter out items where product no longer exists
    cart.items = cart.items.filter(item => item.product !== null);
    
    res.json({ success: true, cart });
  } catch (error) {
    next(error);
  }
};

// @desc    Add item to cart
// @route   POST /api/cart/add
// @access  Public
const addToCart = async (req, res, next) => {
  try {
    const { productId, quantity = 1, cartId } = req.body;
    
    if (!cartId) {
      return res.status(400).json({ success: false, message: "Cart ID is required" });
    }
    
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    
    if (product.stock < quantity) {
      return res.status(400).json({ success: false, message: "Not enough stock available" });
    }
    
    let cart = await Cart.findOne({ cartId });
    
    if (!cart) {
      cart = await Cart.create({
        cartId,
        items: [{ product: productId, quantity }]
      });
    } else {
      const itemIndex = cart.items.findIndex(
        item => item.product.toString() === productId
      );
      
      if (itemIndex > -1) {
        // Update quantity
        const newQty = cart.items[itemIndex].quantity + quantity;
        if (product.stock < newQty) {
          return res.status(400).json({ success: false, message: "Not enough stock available" });
        }
        cart.items[itemIndex].quantity = newQty;
      } else {
        // Add new item
        cart.items.push({ product: productId, quantity });
      }
      await cart.save();
    }
    
    await cart.populate("items.product", "brand model price images stock slug");
    res.json({ success: true, message: "Added to cart", cart });
  } catch (error) {
    next(error);
  }
};

// @desc    Update cart item quantity
// @route   PUT /api/cart/update
// @access  Public
const updateCartItem = async (req, res, next) => {
  try {
    const { productId, quantity, cartId } = req.body;
    
    if (!cartId) {
      return res.status(400).json({ success: false, message: "Cart ID is required" });
    }
    
    if (quantity < 1) {
      return res.status(400).json({ success: false, message: "Quantity must be at least 1" });
    }
    
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    
    if (product.stock < quantity) {
      return res.status(400).json({ success: false, message: "Not enough stock available" });
    }
    
    const cart = await Cart.findOne({ cartId });
    
    if (!cart) {
      return res.status(404).json({ success: false, message: "Cart not found" });
    }
    
    const itemIndex = cart.items.findIndex(
      item => item.product.toString() === productId
    );
    
    if (itemIndex === -1) {
      return res.status(404).json({ success: false, message: "Item not found in cart" });
    }
    
    cart.items[itemIndex].quantity = quantity;
    await cart.save();
    await cart.populate("items.product", "brand model price images stock slug");
    res.json({ success: true, message: "Cart updated", cart });
  } catch (error) {
    next(error);
  }
};

// @desc    Remove item from cart
// @route   DELETE /api/cart/remove/:productId?cartId=xxx
// @access  Public
const removeFromCart = async (req, res, next) => {
  try {
    const { cartId } = req.query;
    
    if (!cartId) {
      return res.status(400).json({ success: false, message: "Cart ID is required" });
    }
    
    const cart = await Cart.findOne({ cartId });
    
    if (!cart) {
      return res.status(404).json({ success: false, message: "Cart not found" });
    }
    
    cart.items = cart.items.filter(
      item => item.product.toString() !== req.params.productId
    );
    await cart.save();
    await cart.populate("items.product", "brand model price images stock slug");
    res.json({ success: true, message: "Item removed from cart", cart });
  } catch (error) {
    next(error);
  }
};

// @desc    Clear cart
// @route   DELETE /api/cart/clear?cartId=xxx
// @access  Public
const clearCart = async (req, res, next) => {
  try {
    const { cartId } = req.query;
    
    if (!cartId) {
      return res.status(400).json({ success: false, message: "Cart ID is required" });
    }
    
    const cart = await Cart.findOne({ cartId });
    
    if (cart) {
      cart.items = [];
      await cart.save();
    }
    res.json({ success: true, message: "Cart cleared" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getCart,
  addToCart,
  updateCartItem,
  removeFromCart,
  clearCart
};
