const crypto = require("crypto");
const axios = require("axios");
const Order = require("../models/Order");
const Product = require("../models/Product");
const { sendEmail, notifyAdmin } = require("../utils/sendEmail");
const templates = require("../utils/emailTemplates");

// @desc    Initialize Paystack transaction
// @route   POST /api/payment/initialize
// @access  Public
const initializePayment = async (req, res, next) => {
  try {
    const { email, amount, orderId } = req.body;
    
    if (!email || !amount) {
      return res.status(400).json({ success: false, message: "Email and amount are required" });
    }

    // Convert amount to kobo (Paystack requirement)
    const amountInKobo = Math.round(amount * 100);
    const reference = `MS-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    const response = await axios.post(
      "https://api.paystack.co/transaction/initialize",
      {
        email,
        amount: amountInKobo,
        reference,
        callback_url: `${process.env.FRONTEND_URL || "http://localhost:3000"}/order-success.html`,
        metadata: {
          orderId,
          customerEmail: email,
          custom_fields: [
            {
              display_name: "Store",
              variable_name: "store",
              value: "MobileShop"
            }
          ]
        }
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    if (response.data.status) {
      res.json({
        success: true,
        message: "Payment initialized",
        data: {
          authorization_url: response.data.data.authorization_url,
          access_code: response.data.data.access_code,
          reference
        }
      });
    } else {
      res.status(400).json({
        success: false,
        message: response.data.message || "Failed to initialize payment"
      });
    }
  } catch (error) {
    console.error("Paystack init error:", error.response?.data || error.message);
    res.status(500).json({
      success: false,
      message: "Payment initialization failed. Please try again."
    });
  }
};

// @desc    Verify Paystack transaction
// @route   POST /api/payment/verify
// @access  Public
const verifyPayment = async (req, res, next) => {
  try {
    const { reference } = req.body;
    
    if (!reference) {
      return res.status(400).json({ success: false, message: "Payment reference is required" });
    }

    const response = await axios.get(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`
        }
      }
    );

    if (!response.data.status) {
      return res.status(400).json({
        success: false,
        message: response.data.message || "Payment verification failed"
      });
    }

    const transactionData = response.data.data;
    const { status, amount, customer, reference: paystackRef, metadata } = transactionData;

    if (status !== "success") {
      return res.status(400).json({
        success: false,
        message: `Payment not successful. Status: ${status}`,
        paymentStatus: status
      });
    }

    // Convert amount from kobo to Naira
    const amountInNaira = amount / 100;

    // Find order by payment reference or metadata orderId
    let order = await Order.findOne({ paymentReference: paystackRef });
    
    if (!order && metadata?.orderId) {
      order = await Order.findById(metadata.orderId);
    }

    // Idempotency check: don't process twice
    if (order && order.paymentStatus === "paid") {
      return res.json({
        success: true,
        message: "Payment already verified",
        order: {
          id: order._id,
          orderNumber: order.orderNumber,
          total: order.total,
          paymentStatus: order.paymentStatus
        }
      });
    }

    if (order) {
      // Verify amount matches (allow small variance)
      if (Math.abs(order.total - amountInNaira) > 100) {
        order.paymentStatus = "failed";
        order.paystackData = transactionData;
        await order.save();
        return res.status(400).json({
          success: false,
          message: "Amount mismatch. Payment verification failed."
        });
      }

      // Update order
      order.paymentStatus = "paid";
      order.paymentReference = paystackRef;
      order.paystackData = transactionData;
      await order.save();

      // Send payment receipt email
      try {
        const receiptHtml = templates.paymentReceiptEmail(order);
        await sendEmail({
          to: order.customerEmail,
          subject: `Payment Receipt - Order ${order.orderNumber}`,
          html: receiptHtml,
          type: "payment-receipt",
          orderId: order._id
        });

        // Notify admin
        await notifyAdmin(
          `Payment Received - ${order.orderNumber}`,
          `<p><strong>Order:</strong> ${order.orderNumber}</p><p><strong>Customer:</strong> ${order.customerName} (${order.customerEmail})</p><p><strong>Phone:</strong> ${order.customerPhone}</p><p><strong>Amount:</strong> ₦${order.total.toLocaleString()}</p><p><strong>Reference:</strong> ${paystackRef}</p>`
        );
      } catch (emailError) {
        console.error("Email send failed (non-critical):", emailError.message);
      }
    }

    res.json({
      success: true,
      message: "Payment verified successfully",
      paymentStatus: "paid",
      amount: amountInNaira,
      reference: paystackRef,
      order: order ? {
        id: order._id,
        orderNumber: order.orderNumber,
        total: order.total,
        paymentStatus: order.paymentStatus,
        orderStatus: order.orderStatus
      } : null
    });
  } catch (error) {
    console.error("Paystack verify error:", error.response?.data || error.message);
    res.status(500).json({
      success: false,
      message: "Payment verification failed. Please contact support."
    });
  }
};

// @desc    Paystack webhook handler
// @route   POST /api/payment/webhook
// @access  Public (Paystack only)
const handleWebhook = async (req, res) => {
  try {
    const hash = crypto.createHmac("sha512", process.env.PAYSTACK_SECRET_KEY)
      .update(JSON.stringify(req.body))
      .digest("hex");

    if (hash !== req.headers["x-paystack-signature"]) {
      return res.status(401).send("Invalid signature");
    }

    const event = req.body;
    const { event: eventType, data } = event;

    if (eventType === "charge.success") {
      const { reference, amount, customer, status } = data;
      const amountInNaira = amount / 100;

      let order = await Order.findOne({ paymentReference: reference });

      if (order && order.paymentStatus !== "paid") {
        if (Math.abs(order.total - amountInNaira) <= 100) {
          order.paymentStatus = "paid";
          order.paystackData = data;
          await order.save();

          // Send emails
          try {
            const receiptHtml = templates.paymentReceiptEmail(order);
            await sendEmail({
              to: order.customerEmail,
              subject: `Payment Receipt - Order ${order.orderNumber}`,
              html: receiptHtml,
              type: "payment-receipt",
              orderId: order._id
            });

            await notifyAdmin(
              `Payment Received (Webhook) - ${order.orderNumber}`,
              `<p><strong>Order:</strong> ${order.orderNumber}</p><p><strong>Customer:</strong> ${order.customerName} (${order.customerEmail})</p><p><strong>Phone:</strong> ${order.customerPhone}</p><p><strong>Amount:</strong> ₦${order.total.toLocaleString()}</p>`
            );
          } catch (emailError) {
            console.error("Webhook email failed:", emailError.message);
          }
        }
      }
    }

    res.status(200).send("OK");
  } catch (error) {
    console.error("Webhook error:", error.message);
    res.status(500).send("Error");
  }
};

module.exports = {
  initializePayment,
  verifyPayment,
  handleWebhook
};
