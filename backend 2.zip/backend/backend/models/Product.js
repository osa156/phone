const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
  brand: {
    type: String,
    required: [true, "Brand is required"],
    enum: ["Infinix", "Apple", "Samsung"],
    index: true
  },
  model: {
    type: String,
    required: [true, "Model name is required"],
    trim: true
  },
  year: {
    type: Number,
    required: [true, "Year is required"],
    min: 2022,
    max: 2026,
    index: true
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  price: {
    type: Number,
    required: [true, "Price is required"],
    index: true
  },
  originalPrice: {
    type: Number
  },
  discount: {
    type: Number,
    default: 0
  },
  description: {
    type: String,
    required: [true, "Description is required"]
  },
  specifications: {
    display: String,
    processor: String,
    ram: String,
    storage: String,
    camera: String,
    battery: String,
    os: String,
    connectivity: String,
    weight: String,
    dimensions: String
  },
  images: [{
    type: String,
    required: true
  }],
  colors: [{
    name: String,
    hex: String
  }],
  stock: {
    type: Number,
    default: 50,
    min: 0
  },
  rating: {
    type: Number,
    default: 4.5,
    min: 0,
    max: 5
  },
  numReviews: {
    type: Number,
    default: 0
  },
  reviews: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    name: String,
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: String,
    date: { type: Date, default: Date.now }
  }],
  isFeatured: {
    type: Boolean,
    default: false
  },
  isNewArrival: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, { timestamps: true });

// Compound indexes
productSchema.index({ brand: 1, year: 1 });
productSchema.index({ price: 1 });
productSchema.index({ model: "text", brand: "text", description: "text" });

// Auto-generate slug before validation
productSchema.pre("validate", function (next) {
  if (!this.slug) {
    this.slug = `${this.brand}-${this.model}-${this.year}`.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
  }
  next();
});

// Auto-calculate discount
productSchema.pre("save", function (next) {
  if (this.originalPrice && this.originalPrice > this.price) {
    this.discount = Math.round(((this.originalPrice - this.price) / this.originalPrice) * 100);
  } else {
    this.discount = 0;
  }
  next();
});

module.exports = mongoose.model("Product", productSchema);
