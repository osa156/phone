const mongoose = require("mongoose");

const emailLogSchema = new mongoose.Schema({
  to: {
    type: String,
    required: true
  },
  subject: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ["welcome", "login-alert", "password-reset", "password-reset-confirm", "order-confirmation", "payment-receipt", "admin-notification", "shipping-update", "contact-reply"],
    required: true,
    index: true
  },
  html: String,
  status: {
    type: String,
    enum: ["sent", "failed"],
    default: "sent"
  },
  error: String,
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  order: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Order"
  }
}, { timestamps: true });

module.exports = mongoose.model("EmailLog", emailLogSchema);
